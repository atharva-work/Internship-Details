# Penetration testing labs solution by VTF for HACTIFY labs

## **Week 1 Lab Solutions**

[Burp Suite.pdf](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Burp_Suite.pdf)

## **Week 2 Lab Solutions**

[HTML Injection](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/HTML%20Injection%2023c472001e464d51a41bff0943806a7a.md)

[Clickjacking](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Clickjacking%20401c3a9daa31437fb77d56a7e0860d74.md)

[Week 2 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%202%20Lab%20Solutions%20a120acc2f1474d1d88dedf9007e762f4.md)

## **Week 3 Lab Solutions**

[Cross-Site Scripting (XSS)](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Cross-Site%20Scripting%20(XSS)%205b0dd813c77442f0b04e45b9fe96fbc3.md)

[Week 3 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%203%20Lab%20Solutions%201e104fd9e6e94a29b8ae45c5c9748ff7.md)

## **Week 4 Lab Solutions**

[Open Redirect](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Open%20Redirect%20e1f1c9cfce18466788d16aba3c1386f1.md)

[EXIF Data Exposure](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/EXIF%20Data%20Exposure%208e252a2d0d33478ab584bfc3f038a04b.md)

[Week 4 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%204%20Lab%20Solutions%20ed406a5b11464e2aa462965fc427e624.md)

## **Week 5 Lab Solutions**

[Cross Origin Resource Sharing (CORS)](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Cross%20Origin%20Resource%20Sharing%20(CORS)%20effab794eb5b447194caca2dc9b9e136.md)

[Week 5 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%205%20Lab%20Solutions%20d34c7decd657491ab5ccc17e5d1fd309.md)

## **Week 6 Lab Solutions**

[Cross Site Request Forgery (CSRF)](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Cross%20Site%20Request%20Forgery%20(CSRF)%207587991bc27044e4b55edf288bc0c8c3.md)

[Week 6 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%206%20Lab%20Solutions%205563abdcbbc34d2e877cdd4d4cad082b.md)

## **Week 7 Lab Solutions**

[SSRF: Server-side request forgery](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/SSRF%20Server-side%20request%20forgery%205e975cd86d4849ae895e8ea0f52fddb9.md)

[Week 7 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%207%20Lab%20Solutions%20e6d8607fb4e0438dbf0cd86297e97c71.md)

## **Week 8 Lab Solutions**

[IDOR: Insecure direct object reference](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/IDOR%20Insecure%20direct%20object%20reference%202fee13f570834939a239a5d69d99c7b7.md)

[Week 8 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%208%20Lab%20Solutions%20160aff2f48a74e558e4976c3294f6a2f.md)

## **Week 9 Lab Solutions**

[SQL Injection](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/SQL%20Injection%20f4b100898be7496eaddb06ce2ae32a2d.md)

[Week 9 Lab Solutions](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%209%20Lab%20Solutions%209349fd14faaf46c780931ccc696a14ee.md)

[SQL Injection](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/SQL%20Injection%20d25598465cda4281b93d72a657a94a66.md)

## **Week 10 Lab Solutions**

[Week 10 : Final WebApp](Penetration%20testing%20labs%20solution%20by%20VTF%20for%20HACTI%20dee6b14ae2f74c2f86bf2a25d97b3436/Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e.md)