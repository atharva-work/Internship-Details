# Week 10 : Final WebApp

## Introduction to the Lab

This Lab is a kind of CTF challenge where we need to find the final `flag.txt` Over here we have a web application which tells us to log in. 

## Steps to Reproduce

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled.png)

Ahaan! A log in page. A great way to bypass it is using SQL Injection. But for that we need to know what query the developer has written at the backend. Let's try adding `'` first

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%201.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%201.png)

Oops! No success! Lets try adding a `"` 

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%202.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%202.png)

Perfect! we got the SQL syntax error! Alright let's try to break the error and understand the query at the backend

`'""") LIMIT 0,1'` Over here the outside `'`s are the part of query. The inside set of `"`s represent our input. And the second `"` denotes our input. The `) LIMIT 0,1` is the part of the query. 

The query running at the backend to display a list of users must be something:

`$query = "SELECT * FROM table WHERE email=($email) AND password=($password) LIMIT 0,1";`

Alright then let's use the payload `") || ("1")=("1` to bypass.

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%203.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%203.png)

Perfect! So this completes our first task to enter the web application! Alright! so we have a WebPage Loader which takes in a URL! How about supplying `127.0.0.1` to get an internal dashboard and exploiting SSRF

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%204.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%204.png)

Oops! We were blocked! Let's try it using `localhost`

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%204.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%204.png)

Oops! Blocked Again! This time let's try adding `http://[::]`

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%205.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%205.png)

Perfect! We weren't blocked. But still we didn't find the flag! Well we are looking it for port 80! How about looking it for some other port! Commonly developers hide it on port 4444,8000,8080 etc.

Let's try out `8000` first. So lets enter `http://[::]:8000` 

![Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%206.png](Week%2010%20Final%20WebApp%2083a26ef5b3c947449c82c5c19a7c4f0e/Untitled%206.png)

Awesome! We found our flag that is `flag{Th1s_1s_y0ur_fl4g}`

## Payload(s) Used

For SQL Injection to bypass the login page : `") || ("1")=("1`

For SSRF to get the final flag : `http://[::]:8000`

## Conclusion

This lab was an attempt to test your skills in Web Application penetration testing.