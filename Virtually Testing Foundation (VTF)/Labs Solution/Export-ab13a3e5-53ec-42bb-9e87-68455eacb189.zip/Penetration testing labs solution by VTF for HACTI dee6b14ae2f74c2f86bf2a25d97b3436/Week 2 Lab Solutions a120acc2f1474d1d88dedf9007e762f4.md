# Week 2 Lab Solutions

[HTML Injection Lab Solutions](Week%202%20Lab%20Solutions%20a120acc2f1474d1d88dedf9007e762f4/HTML%20Injection%20Lab%20Solutions%20662a996d8d044d6b84e4f6c89cf80021.md) 

[Clickjacking Lab Solutions](Week%202%20Lab%20Solutions%20a120acc2f1474d1d88dedf9007e762f4/Clickjacking%20Lab%20Solutions%20214a5b1d4a3d4a56a0f5e4b4c2b6ee96.md)