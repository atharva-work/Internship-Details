# Clickjacking Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: Let's Hijack!](Clickjacking%20Lab%20Solutions%20214a5b1d4a3d4a56a0f5e4b4c2b6ee96/Lab%201%20Let's%20Hijack!%20dc10dbd5110349ee9a6679e42f474642.md)

[Lab 2: Re-Hijack!](Clickjacking%20Lab%20Solutions%20214a5b1d4a3d4a56a0f5e4b4c2b6ee96/Lab%202%20Re-Hijack!%200e613b48e9a044d686935cfe5d20940f.md)