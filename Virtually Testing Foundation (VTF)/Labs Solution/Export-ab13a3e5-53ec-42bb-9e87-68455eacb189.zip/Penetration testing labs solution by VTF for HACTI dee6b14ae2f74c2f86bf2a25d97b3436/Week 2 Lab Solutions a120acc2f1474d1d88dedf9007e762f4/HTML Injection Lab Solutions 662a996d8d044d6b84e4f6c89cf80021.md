# HTML Injection Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: HTML's are easy!](HTML%20Injection%20Lab%20Solutions%20662a996d8d044d6b84e4f6c89cf80021/Lab%201%20HTML's%20are%20easy!%2075d8a462eb8241b6a494dd45c21d5efe.md)

[Lab 2: Let me Store them!](HTML%20Injection%20Lab%20Solutions%20662a996d8d044d6b84e4f6c89cf80021/Lab%202%20Let%20me%20Store%20them!%20cef1881dc8fb4a069e2215d16e3176b1.md)

[Lab 3: File Names are also vulnerable!](HTML%20Injection%20Lab%20Solutions%20662a996d8d044d6b84e4f6c89cf80021/Lab%203%20File%20Names%20are%20also%20vulnerable!%20a5aef8b7c7334e98a06d9310e285f700.md)

[Lab 4: File Content and HTML Injection a perfect pair!](HTML%20Injection%20Lab%20Solutions%20662a996d8d044d6b84e4f6c89cf80021/Lab%204%20File%20Content%20and%20HTML%20Injection%20a%20perfect%20pa%20b5c876dba8ff41a2a80f575ed55fac4b.md)

[Lab 5: Injecting HTML using URL](HTML%20Injection%20Lab%20Solutions%20662a996d8d044d6b84e4f6c89cf80021/Lab%205%20Injecting%20HTML%20using%20URL%20ff3a62bccf5e44c2a90910de414e4ee0.md)

[Lab 6: Encode IT!](HTML%20Injection%20Lab%20Solutions%20662a996d8d044d6b84e4f6c89cf80021/Lab%206%20Encode%20IT!%20f732c31780c74162bb7871767ff5dbfd.md)