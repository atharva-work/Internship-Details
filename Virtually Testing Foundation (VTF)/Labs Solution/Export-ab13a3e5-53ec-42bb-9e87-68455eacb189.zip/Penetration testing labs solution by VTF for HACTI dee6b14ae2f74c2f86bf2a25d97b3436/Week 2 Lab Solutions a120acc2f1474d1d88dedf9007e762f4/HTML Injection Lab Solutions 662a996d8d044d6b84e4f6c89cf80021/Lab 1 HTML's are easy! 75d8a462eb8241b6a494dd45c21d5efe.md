# Lab 1: HTML's are easy!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how HTML Injection is done in real-life scenario.

Over here we have a search bar where in we can search anything!

## Steps to Reproduce

![Lab%201%20HTML's%20are%20easy!%2075d8a462eb8241b6a494dd45c21d5efe/Untitled.png](Lab%201%20HTML's%20are%20easy!%2075d8a462eb8241b6a494dd45c21d5efe/Untitled.png)

Um-Hmm! A search bar let's try to search for something!

![Lab%201%20HTML's%20are%20easy!%2075d8a462eb8241b6a494dd45c21d5efe/Untitled%201.png](Lab%201%20HTML's%20are%20easy!%2075d8a462eb8241b6a494dd45c21d5efe/Untitled%201.png)

Ahaan! Whatever I search for is being reflected on the webpage! Lets try to insert a simple payload of h1 tag. The payload will be `<h1>Hello World</h1>`

![Lab%201%20HTML's%20are%20easy!%2075d8a462eb8241b6a494dd45c21d5efe/Untitled%202.png](Lab%201%20HTML's%20are%20easy!%2075d8a462eb8241b6a494dd45c21d5efe/Untitled%202.png)

Woahh! Our payload got executed. This clearly states that the page is vulnerable to HTML Injection

## Payload(s) Used

The payload used in this lab was `<h1>Hello World</h1>`. You can use any other HTML Tag in order to exploit the vulnerability.

## Conclusion

This lab was an attempt to provide how HTML Injection can be exploited by adding a simple HTML Injection payload. The HTML Injection vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.