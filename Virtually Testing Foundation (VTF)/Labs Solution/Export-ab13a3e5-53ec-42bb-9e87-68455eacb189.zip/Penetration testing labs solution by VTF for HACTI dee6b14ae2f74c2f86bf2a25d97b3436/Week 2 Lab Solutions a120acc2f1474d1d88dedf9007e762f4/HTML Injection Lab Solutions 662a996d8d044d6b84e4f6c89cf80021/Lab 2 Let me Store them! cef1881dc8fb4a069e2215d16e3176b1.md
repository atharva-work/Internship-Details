# Lab 2: Let me Store them!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how HTML Injection Payloads can be stored.

Over here we have a functionality of Register/ Login.

## Steps to Reproduce

![Lab%202%20Let%20me%20Store%20them!%20cef1881dc8fb4a069e2215d16e3176b1/Untitled.png](Lab%202%20Let%20me%20Store%20them!%20cef1881dc8fb4a069e2215d16e3176b1/Untitled.png)

So let's quickly register an account and Log In.

Once you log in you will be able to Update `User Profile` 

Remember how balancing works for XSS. Looking at the source code the same we have to do for our HTML Injection payload. Lets put our Payload in the fields of `First Name` and `Last Name`. The final payload will be `"><b>xyz</b>` and `"><b>xyz</b>` respectively

![Lab%202%20Let%20me%20Store%20them!%20cef1881dc8fb4a069e2215d16e3176b1/Untitled%201.png](Lab%202%20Let%20me%20Store%20them!%20cef1881dc8fb4a069e2215d16e3176b1/Untitled%201.png)

Perfect! Let's quickly update our profile and check out if our payload gets stored or not!

![Lab%202%20Let%20me%20Store%20them!%20cef1881dc8fb4a069e2215d16e3176b1/Untitled%202.png](Lab%202%20Let%20me%20Store%20them!%20cef1881dc8fb4a069e2215d16e3176b1/Untitled%202.png)

Amazing our payload got stored in the User Profile Section! Well done Hacker H! HTML Injection was executed successfully!

## Payload(s) Used

The payload used in this lab was `"><b>abc</b>`. You can use any other HTML Tag with proper balancing in order to exploit the vulnerability.

## 

## Conclusion

This lab was an attempt to provide how HTML Injection can be exploited by adding a simple HTML Injection payload. The HTML Injection vulnerability we saw in this lab was stored which has a severity of P3 with a CVSS score of 4.0-6.9 which is Medium.