# Lab 3: File Names are also vulnerable!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how HTML Injection can be done using the file name.

Over here you can see a file upload functionally. 

## Steps to Reproduce

![Lab%203%20File%20Names%20are%20also%20vulnerable!%20a5aef8b7c7334e98a06d9310e285f700/Untitled.png](Lab%203%20File%20Names%20are%20also%20vulnerable!%20a5aef8b7c7334e98a06d9310e285f700/Untitled.png)

File Upload!! Mhhhmmm! Niceee! Now there can be only 2 situations. Either upload the HTML Injection Payload as content or as File Name.

Let's test it out with File Name first! Quickly let's create a `txt file` with the name `"><iframe src="malware_iframe.html">.txt`.  

![Lab%203%20File%20Names%20are%20also%20vulnerable!%20a5aef8b7c7334e98a06d9310e285f700/Untitled%201.png](Lab%203%20File%20Names%20are%20also%20vulnerable!%20a5aef8b7c7334e98a06d9310e285f700/Untitled%201.png)

Perfect! Now let's upload this file and check out what happens!

![Lab%203%20File%20Names%20are%20also%20vulnerable!%20a5aef8b7c7334e98a06d9310e285f700/Untitled%202.png](Lab%203%20File%20Names%20are%20also%20vulnerable!%20a5aef8b7c7334e98a06d9310e285f700/Untitled%202.png)

Amazing! Notice our file upload leads to HTML Injection on the webpage! Nice! Another amazing type of HTML Injection!

## Payload(s) Used

In this lab we created a file with the name `"><iframe src="malware_iframe.html">.txt`. You can use any other HTML Tag in the file name.

## 

## Conclusion

This lab was an attempt to provide how HTML Injection can be exploited by using payload in the file name. The HTML Injection vulnerability we saw in this lab was stored which has a severity of P3 with a CVSS score of 4.0-6.9 which is Medium.