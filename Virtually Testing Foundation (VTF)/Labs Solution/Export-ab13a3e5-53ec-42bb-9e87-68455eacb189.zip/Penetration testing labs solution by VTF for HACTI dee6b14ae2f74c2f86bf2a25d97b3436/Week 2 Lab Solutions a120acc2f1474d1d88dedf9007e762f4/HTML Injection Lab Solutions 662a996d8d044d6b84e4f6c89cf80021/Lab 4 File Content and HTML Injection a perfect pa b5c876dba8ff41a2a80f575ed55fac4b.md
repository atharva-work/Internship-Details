# Lab 4: File Content and HTML Injection a perfect pair!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how HTML Injection can be done uploading a file containing HTML Injection payload.

Over here you can see a file upload functionally. 

## Steps to Reproduce

![Lab%204%20File%20Content%20and%20HTML%20Injection%20a%20perfect%20pa%20b5c876dba8ff41a2a80f575ed55fac4b/Untitled.png](Lab%204%20File%20Content%20and%20HTML%20Injection%20a%20perfect%20pa%20b5c876dba8ff41a2a80f575ed55fac4b/Untitled.png)

In the previous lab we had seen that whenever there is a file upload functionality there can be only two situations: File Name and File Content. We have already seen how we can exploit HTML Injection Vulnerability by inserting the payload in File Name. 

In this lab lets try to insert our payload in File Content and upload it in this functionality. The payload used over here is:

```jsx
<?xml version="1.0" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd%22%3E

<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg%22%3E
   <rect width="300" height="100" style="fill:rgb(0,0,255);stroke-width:3;stroke:rgb(0,0,0)" />
   <h1>Hello</h1>
</svg>
```

Awesome let's upload this file on the website.

![Lab%204%20File%20Content%20and%20HTML%20Injection%20a%20perfect%20pa%20b5c876dba8ff41a2a80f575ed55fac4b/Untitled%201.png](Lab%204%20File%20Content%20and%20HTML%20Injection%20a%20perfect%20pa%20b5c876dba8ff41a2a80f575ed55fac4b/Untitled%201.png)

Amazing! Notice our File contents leads to HTML Injection on the webpage! 

## Payload(s) Used

In this lab we created a file with the contents as 

```jsx
<?xml version="1.0" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd%22%3E

<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg%22%3E
   <rect width="300" height="100" style="fill:rgb(0,0,255);stroke-width:3;stroke:rgb(0,0,0)" />
   <h1>Hello</h1>
</svg>
```

and file name as `html.svg`. You can use any other HTML Tag in the file content.

## 

## Conclusion

This lab was an attempt to provide how HTML Injection can be exploited by using payload in the file content. The HTML Injection vulnerability we saw in this lab was stored which has a severity of P3 with a CVSS score of 4.0-6.9 which is Medium.