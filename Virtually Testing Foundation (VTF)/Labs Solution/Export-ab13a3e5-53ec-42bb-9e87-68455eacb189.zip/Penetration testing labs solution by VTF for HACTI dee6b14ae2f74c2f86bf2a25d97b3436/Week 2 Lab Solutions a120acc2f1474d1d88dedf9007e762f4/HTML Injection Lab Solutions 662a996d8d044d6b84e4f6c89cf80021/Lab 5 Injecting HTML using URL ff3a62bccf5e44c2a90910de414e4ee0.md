# Lab 5: Injecting HTML using URL

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how HTML Injection can be done in URL Reflection.

Over here you can see a static page which says `Your URL is`

## Steps to Reproduce

![Lab%205%20Injecting%20HTML%20using%20URL%20ff3a62bccf5e44c2a90910de414e4ee0/Untitled.png](Lab%205%20Injecting%20HTML%20using%20URL%20ff3a62bccf5e44c2a90910de414e4ee0/Untitled.png)

Ahaan! The URL is being reflected on the website. What if I try to insert `?` will it be reflected. Generally developers use `?` in order to put a parameter after it. So let's test that out.

![Lab%205%20Injecting%20HTML%20using%20URL%20ff3a62bccf5e44c2a90910de414e4ee0/Untitled%201.png](Lab%205%20Injecting%20HTML%20using%20URL%20ff3a62bccf5e44c2a90910de414e4ee0/Untitled%201.png)

Amazing!! Notice whatever we type after `?` also gets reflected on the webpage. This can be our entry point for the HTML Injection Payload. Let's use the payload `<h1>Hello</h1>` and check out.

![Lab%205%20Injecting%20HTML%20using%20URL%20ff3a62bccf5e44c2a90910de414e4ee0/Untitled%202.png](Lab%205%20Injecting%20HTML%20using%20URL%20ff3a62bccf5e44c2a90910de414e4ee0/Untitled%202.png)

Woahh! Notice our HTML Injection payload got executed

## Payload(s) Used

The payload used in this lab was `<h1>Hello</h1>`. You can use any other HTML Tag in order to exploit the vulnerability.

## Conclusion

This lab was an attempt to provide how HTML Injection can be exploited when URL is reflected and by inserting HTML Injection payload in the URL. The HTML Injection vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.