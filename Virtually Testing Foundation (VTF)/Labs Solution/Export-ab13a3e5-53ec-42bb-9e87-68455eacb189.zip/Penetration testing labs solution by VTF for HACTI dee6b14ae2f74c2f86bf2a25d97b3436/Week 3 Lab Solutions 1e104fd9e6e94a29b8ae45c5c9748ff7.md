# Week 3 Lab Solutions

[Cross-Site Scripting Lab Solutions](Week%203%20Lab%20Solutions%201e104fd9e6e94a29b8ae45c5c9748ff7/Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27.md)