# Cross-Site Scripting Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: Let's Do IT!](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%201%20Let's%20Do%20IT!%20b316fc98c9c74af69ab8fee7495e3b11.md)

[Lab 2: Balancing is Important in Life!](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b.md)

[Lab 3: XSS is everywhere! ](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%203%20XSS%20is%20everywhere!%204f79b9bdcfaa4c628853f105fab59e5f.md)

[Lab 4: Alternatives are must!](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%204%20Alternatives%20are%20must!%200ef97bc226df4b889e0f8265644f3e03.md)

[Lab 5: Developer hates scripts!](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%205%20Developer%20hates%20scripts!%208fdf231e44c04c7eacbcb5030321bd4e.md)

[Lab 6: Change the Variation!](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%206%20Change%20the%20Variation!%200fb24df9fae644068d043e369dadc0be.md)

[Lab 7: Encoding is the key?](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%207%20Encoding%20is%20the%20key%2083b9191813a64900b08f9469c29ba0ce.md)

[ Lab 8: XSS with File Upload (file name)](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%208%20XSS%20with%20File%20Upload%20(file%20name)%20cd88ef036ae34b629cd93a49fce3d201.md)

[Lab 9: XSS with File Upload (File Content)](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%209%20XSS%20with%20File%20Upload%20(File%20Content)%20af36d2dad59342a2bb16bcd9572e4925.md)

[Lab 10: Stored Everywhere!](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%2010%20Stored%20Everywhere!%204a07ae86c81d4b98a3d068cc20857853.md)

[Lab 11: DOM's are love!](Cross-Site%20Scripting%20Lab%20Solutions%201f228f114b564de98727c650cdcbfd27/Lab%2011%20DOM's%20are%20love!%2074b3b81e4a2c48f28092e65d882154df.md)