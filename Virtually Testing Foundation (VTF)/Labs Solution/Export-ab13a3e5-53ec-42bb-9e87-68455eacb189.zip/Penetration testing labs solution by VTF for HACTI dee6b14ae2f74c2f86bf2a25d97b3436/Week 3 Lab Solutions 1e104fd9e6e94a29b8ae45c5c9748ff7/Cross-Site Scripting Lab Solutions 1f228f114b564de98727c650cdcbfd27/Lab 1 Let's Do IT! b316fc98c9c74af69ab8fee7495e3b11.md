# Lab 1: Let's Do IT!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how Cross Site Scripting (XSS) is done in real-life scenario.

Over here we have a web application which asks for your email address in order to subscribe to their newsletter.

## Steps to Reproduce

So the question arises, How do we find an XSS?

Notice we have an input field to type our Email-Address.

![Lab%201%20Let's%20Do%20IT!%20b316fc98c9c74af69ab8fee7495e3b11/Untitled.png](Lab%201%20Let's%20Do%20IT!%20b316fc98c9c74af69ab8fee7495e3b11/Untitled.png)

MHMM! Sounds Interesting! Lets try to enter our Email Address and check what happens.

![Lab%201%20Let's%20Do%20IT!%20b316fc98c9c74af69ab8fee7495e3b11/Untitled%201.png](Lab%201%20Let's%20Do%20IT!%20b316fc98c9c74af69ab8fee7495e3b11/Untitled%201.png)

Ahaan! So the input is being reflected on the webpage. A great chance of **Reflected XSS**!

Alright! Its time for the exploit! Lets put a simple payload and try out if it works or not.

So over here I will be using the payload `<script>alert(1)</script>`

![Lab%201%20Let's%20Do%20IT!%20b316fc98c9c74af69ab8fee7495e3b11/Untitled%202.png](Lab%201%20Let's%20Do%20IT!%20b316fc98c9c74af69ab8fee7495e3b11/Untitled%202.png)

Perfect! Notice the alert box we got, which successfully states that our payload was executed! 

## Payload(s) Used

I have used the payload which is the most basic form : `<script>alert(1)</script>`. But for this lab any  XSS payload should work.

## Conclusion

This lab was an attempt to provide how XSS works in real-life scenario and how one should have a mindset when hunting for XSS vulnerabilities. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.