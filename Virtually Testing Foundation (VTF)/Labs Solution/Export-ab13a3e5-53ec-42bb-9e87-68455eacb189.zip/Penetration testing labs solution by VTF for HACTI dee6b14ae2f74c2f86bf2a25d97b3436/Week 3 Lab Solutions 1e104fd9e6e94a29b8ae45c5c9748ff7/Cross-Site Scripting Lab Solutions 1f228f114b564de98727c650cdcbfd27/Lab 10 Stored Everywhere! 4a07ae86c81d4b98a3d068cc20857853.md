# Lab 10: Stored Everywhere!

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Stored Cross-Site Scripting can be exploited if there is any input field that stores the value in the database.

Over here we have a web application that asks us to log in or to create an account and let's us update our details.  
Create an account and log in with your credentials.

## Steps to Reproduce

Once we have logged in to the application, we can see there is a update page where we can update our details like first name, last name , email etc.

![https://i.imgur.com/oVApvqQ.png](https://i.imgur.com/oVApvqQ.png)

let's see the source code of the application and see how it desplays the results in the web page.

![https://i.imgur.com/UWO11i6.png](https://i.imgur.com/UWO11i6.png)

We can see that the value like First name and Last name are inside `value=` field.

How about replacing them with our XSS payload? Well, Lets try!

Here, we will be balancing the payload and then the payload will be something like this, 

`"/><script>confirm(1)</script>`

We can use this in every input field changing the number for each filed, like ***`confirm(1)`*** for First name ***`confirm(2)`*** for last name etc.

![https://i.imgur.com/nOfkfrj.png](https://i.imgur.com/nOfkfrj.png)

Let's click update and see what happens!

Got the pop up? Cool! We will be getting 1 and 2 as well, this is because both the input field are vulnerable to Stored XSS.

![https://i.imgur.com/IccJXar.png](https://i.imgur.com/IccJXar.png)

Awesome, We have achieved Stored XSS here. 

## Payload(s) Used

I have used the payload as a file name: `"/><script>confirm(1)</script>` But for this lab, any XSS payload will work fine.

## 

## Conclusion

This lab was an attempt to provide how one can perform Stored XSS when our input gets stored in a database. The XSS we saw in this lab was Stored XSS which has a severity of P2 with a CVSS score of 7-8.9 which is High.