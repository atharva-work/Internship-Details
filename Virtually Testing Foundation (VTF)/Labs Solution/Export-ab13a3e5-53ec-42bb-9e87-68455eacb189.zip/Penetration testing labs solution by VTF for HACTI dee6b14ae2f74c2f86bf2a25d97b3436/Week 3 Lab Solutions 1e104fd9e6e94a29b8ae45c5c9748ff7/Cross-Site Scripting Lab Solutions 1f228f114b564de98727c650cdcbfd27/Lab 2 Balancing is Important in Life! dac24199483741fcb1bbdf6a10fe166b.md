# Lab 2: Balancing is Important in Life!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross Site Scripting (XSS) can be done by balancing the payloads.

Over here we have a web application which asks for your email address in order to subscribe to their newsletter.

## Steps to Reproduce

So, we now know that we can use the Email Address input field in order to pop the alert box and execute our payload. So let's try injecting a basic payload `<script>alert(1)</script>`

![Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled.png](Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled.png)

Oops! That didn't work! But the payload got reflected on the page! So why the alert box didn't pop out??  

Let's have a look at the source code!

![Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled%201.png](Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled%201.png)

Alright! The `value` parameter has our payload `<script>alert(1)</script>` But we want it outside the value.

**It's time to balance the payload!** 

A simple balancing can be done by adding `">` at the beginning of the payload!

So our new payload will be `"><script>alert(1)</script>`

Let's execute it!

![Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled%202.png](Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled%202.png)

Amazing! Our payload got executed!

Let's look at the source code once again for a better understanding!

![Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled%203.png](Lab%202%20Balancing%20is%20Important%20in%20Life!%20dac24199483741fcb1bbdf6a10fe166b/Untitled%203.png)

Notice our payload now gets inserted outside the `value` parameter.

## Payload(s) Used

I have used the payload which is the most basic form with the balancing :

 `"><script>alert(1)</script>` But for this lab any  XSS payload with balancing should work.

## Conclusion

This lab was an attempt to provide how one can perform XSS attack by simply balancing the payload. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.