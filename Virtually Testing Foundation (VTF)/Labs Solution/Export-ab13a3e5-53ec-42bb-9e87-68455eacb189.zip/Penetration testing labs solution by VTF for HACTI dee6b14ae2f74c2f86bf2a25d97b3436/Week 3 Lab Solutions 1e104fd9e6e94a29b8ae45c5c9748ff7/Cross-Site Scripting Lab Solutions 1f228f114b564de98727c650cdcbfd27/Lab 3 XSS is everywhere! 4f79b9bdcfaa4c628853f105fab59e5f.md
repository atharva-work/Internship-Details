# Lab 3: XSS is everywhere!

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross Site Scripting (XSS) can be exploited in Email fields.

Over here we have a web application which asks for your email address in order to subscribe to their newsletter.

## Steps to Reproduce

Alright, again an email field. Let's try to enter a basic payload  `<script>alert(1)</script>` and test out.

![Lab%203%20XSS%20is%20everywhere!%204f79b9bdcfaa4c628853f105fab59e5f/Untitled.png](Lab%203%20XSS%20is%20everywhere!%204f79b9bdcfaa4c628853f105fab59e5f/Untitled.png)

Oh! This time the web application is checking out if the Email Address entered is valid or not!

Let's reframe our payload to look like an email. So the new payload will look:

 `<script>alert(1)</script>@gmail.com`

Let's try this!

![Lab%203%20XSS%20is%20everywhere!%204f79b9bdcfaa4c628853f105fab59e5f/Untitled%201.png](Lab%203%20XSS%20is%20everywhere!%204f79b9bdcfaa4c628853f105fab59e5f/Untitled%201.png)

Amazing! Our payload got executed!

## Payload(s) Used

I have used the payload which is the most basic form and looks like an Email Address :

 `"><script>alert(1)</script>@gmail.com` But for this lab any XSS payload which looks like an Email Address should work.

## Conclusion

This lab was an attempt to provide how one can perform XSS attack in email address fields. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.