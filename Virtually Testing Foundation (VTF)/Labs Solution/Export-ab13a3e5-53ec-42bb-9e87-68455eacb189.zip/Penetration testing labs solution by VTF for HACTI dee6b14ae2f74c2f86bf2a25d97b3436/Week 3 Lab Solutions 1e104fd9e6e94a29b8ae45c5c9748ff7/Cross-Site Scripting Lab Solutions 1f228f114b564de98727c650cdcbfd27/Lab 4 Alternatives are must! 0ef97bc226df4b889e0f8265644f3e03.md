# Lab 4: Alternatives are must!

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross Site Scripting (XSS) can be exploited if the alert box is blocked by the web application

Over here we have a web application which asks for your email address in order to subscribe to their newsletter.

## Steps to Reproduce

Alright, again an email field. Let's try to enter a basic payload  `<script>alert(1)</script>` and test out.

![Lab%204%20Alternatives%20are%20must!%200ef97bc226df4b889e0f8265644f3e03/Untitled.png](Lab%204%20Alternatives%20are%20must!%200ef97bc226df4b889e0f8265644f3e03/Untitled.png)

So, the alert box did not pop up! No issues we know that Balancing is Important!

Checking the source code we come to know that the payload will be `"><script>alert(1)</script>`

Let's try it!

![Lab%204%20Alternatives%20are%20must!%200ef97bc226df4b889e0f8265644f3e03/Untitled%201.png](Lab%204%20Alternatives%20are%20must!%200ef97bc226df4b889e0f8265644f3e03/Untitled%201.png)

Snap! The payload was balanced, then why didn't the alert box pop out ???!!

Let's reframe our payload but this time instead of alert lets use an alternative which is either **confirm or prompt**. So the new payload will look:

`"><script>confirm(1)</script>` or `"><script>prompt(1)</script>`

Let's try this!

![Lab%204%20Alternatives%20are%20must!%200ef97bc226df4b889e0f8265644f3e03/Untitled%202.png](Lab%204%20Alternatives%20are%20must!%200ef97bc226df4b889e0f8265644f3e03/Untitled%202.png)

Amazing! Our payload got executed!

## Payload(s) Used

I have used the payload which is the most basic form and has confirm/prompt :

 `"><script>confirm(1)</script>` or `"><script>prompt(1)</script`  But for this lab any XSS payload which has confirm/prompt should work.

## Conclusion

This lab was an attempt to provide how one can perform XSS when `alert` is blocked . In such a case the alternatives confirm or prompt can work. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.