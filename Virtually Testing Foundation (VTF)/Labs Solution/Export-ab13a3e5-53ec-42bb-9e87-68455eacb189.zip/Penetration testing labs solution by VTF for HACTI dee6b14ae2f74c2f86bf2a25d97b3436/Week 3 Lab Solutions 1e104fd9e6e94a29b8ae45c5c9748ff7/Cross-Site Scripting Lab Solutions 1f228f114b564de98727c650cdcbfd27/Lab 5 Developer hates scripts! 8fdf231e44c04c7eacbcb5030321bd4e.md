# Lab 5: Developer hates scripts!

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross Site Scripting (XSS) can be exploited if the `<script>` tag is blocked by the web application

Over here we have a web application which asks for your email address in order to subscribe to their newsletter.

## Steps to Reproduce

Alright, again an email field. Let's try to enter a basic payload  `<script>alert(1)</script>` and test out.

![Lab%205%20Developer%20hates%20scripts!%208fdf231e44c04c7eacbcb5030321bd4e/Untitled.png](Lab%205%20Developer%20hates%20scripts!%208fdf231e44c04c7eacbcb5030321bd4e/Untitled.png)

Ahaan! The developer became smart! He replaced the `<script>` tag with `<sc_ipt>` so that the attacker cannot perform an XSS!

But Hacker's do find a way to exploit! :P But first lets see the source code and check out if `value` parameter stores it in the same way or the developer just fooled us around!

![Lab%205%20Developer%20hates%20scripts!%208fdf231e44c04c7eacbcb5030321bd4e/Untitled%201.png](Lab%205%20Developer%20hates%20scripts!%208fdf231e44c04c7eacbcb5030321bd4e/Untitled%201.png)

Alright! so the developer, indeed, stores `<script>` tag as `<sc_ipt>` Moreover we got to know that we need to balance our payload!

No issues lets try another payload which does not have a `<script>` tag! 

So here am going to use the payload `<img src=x onerror=alert(1)>`

Let me break it down for you!

`<img src=x` states "Load a image from a source x"

`onerror=alert(1)>` states "If there's an error give me an alert with the value 1

Over here `x` cannot be a source or you can say it's a wrong source, so obviously we are going to get an alert box!

Ohh! I almost forgot to balance the payload! Let's balance it. The new payload will be 

`"><img src=x onerror=alert(1)>`

Let's try this!

![Lab%205%20Developer%20hates%20scripts!%208fdf231e44c04c7eacbcb5030321bd4e/Untitled%202.png](Lab%205%20Developer%20hates%20scripts!%208fdf231e44c04c7eacbcb5030321bd4e/Untitled%202.png)

Amazing! Our payload got executed!

The developer only blocked the `<script>` tags, But we were smarter than him!

## Payload(s) Used

I have used the payload : `"><img src=x onerror=alert(1)>` But for this lab any XSS payload which does not contain `<script>` tag should work.

## Conclusion

This lab was an attempt to provide how one can perform XSS when `<script>` tags are blocked . In such a case other payloads like `<img src=x onerror=alert(1)>` can be very useful. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.