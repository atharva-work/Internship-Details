# Lab 6: Change the Variation!

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross-Site Scripting (XSS) can be exploited if the `<script>` tag is blocked by the web application that too using `<script>` tag. Interesting, isn't it?

Over here we have a web application which asks for your email address in order to subscribe to their newsletter as we have already know .

## Steps to Reproduce

Alright, again an email field. Let's try to enter a basic payload  `<script>alert(1)</script>` and test out.

![https://i.imgur.com/FdXFBQY.png](https://i.imgur.com/FdXFBQY.png)

Oops! Where does the `<script>` tag go in the search bar? Maybe the server is removing our favourite `<script>` tag for which our payload isn't working.

Let's see if we can find a way to bypass this check, for that let's look into the source code to see what is there.

![https://i.imgur.com/kT58PCS.png](https://i.imgur.com/kT58PCS.png)

Ummm, Fine enough! So we can't use `<script>` tag here, but can we bypass this, framing a new type of payload which may eventually fool the server? Yes, we can!!!

Let's see how we can do that, So there is a check on `<script>` , but what if we use `<scr<script>ipt>` instead of simple `<script>` ? Well, Let's check it out.

![https://i.imgur.com/FR0ZUAX.png](https://i.imgur.com/FR0ZUAX.png)

Awesome, We have bypassed this check right? Yes, we have!! Time to get a pop up here, Before that let's frame a payload with the bypass that we have found for this check. 

Simple right? We can use `"><scr<script>ipt>alert(1)</scr</script>ipt>` to bypass the `<script>` check because we have already seen that `alert(1)` remains as it is. Don't forget to balance the payload because it was reflected inside a `value=` parameter.

Let's put the above framed payload and see how it works!

![https://i.imgur.com/4fpPg4G.png](https://i.imgur.com/4fpPg4G.png)

It Worked! Awesome :)

## Payload(s) Used

I have used the payload : `"><scr<script>ipt>alert(1)</scr</script>ipt>` But for this lab any XSS payload which does not contain `<script>` tag should work.

## Conclusion

This lab was an attempt to provide how one can perform XSS when `<script>` tags are blocked and never reflected directly. In such a case other payloads like `"><scr<script>ipt>alert(1)</scr</script>ipt>` can be very useful. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.