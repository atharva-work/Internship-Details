# Lab 7: Encoding is the key?

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross-Site Scripting (XSS) can be exploited if the special characters like `<, >,:,; < ",/,  =, (, ) {, },'`  are blocked by the web application.

Over here we have a web application that asks for your email address in order to subscribe to their newsletter as we have already known.

## Steps to Reproduce

Alright, again an email field. Let's try to enter a basic payload  `<script>alert(1)</script>` and test out.

![https://i.imgur.com/kXqJUIf.png](https://i.imgur.com/kXqJUIf.png)

See, our special characters have been disappeared. Let's see how it is reflected in the source code.

![https://i.imgur.com/sFuK2Dl.png](https://i.imgur.com/sFuK2Dl.png)

Here also, we can't find our special characters. How can we get XSS here? 

It's pretty easy, Here we introduce the concept of URL Encoding.

**What is URL Encoding?**

→  URL encoding converts characters into a format that can be transmitted over the Internet.

So let's try to encode our special characters and see if they work. For this "`<`" will become "`%3C`" , "`>`" will become "`%3E`" , "`(`" will become "`%28`", "`)`" will become "`%29`" and "`/`" will become "`%2F`" which can combined to make this URL encoded payload: `%3Cscript%3Ealert%281%29%3C%2Fscript%3E` which is nothing but `<script>alert(1)</script>`

You can use [this](https://meyerweb.com/eric/tools/dencoder/) online tool to convert them.

Now, let's change the payload and see if we get the pop up!

![https://i.imgur.com/2YQiCC9.png](https://i.imgur.com/2YQiCC9.png)

 Awesome :)

## Payload(s) Used

I have used the payload: `%3Cscript%3Ealert%281%29%3C%2Fscript%3E` But for this lab, any XSS payload with URL encoded special characters will work fine.

## Conclusion

This lab was an attempt to provide how one can perform XSS when special characters are blocked and never reflected directly. In such a case other payloads like `%3Cscript%3Ealert%281%29%3C%2Fscript%3E` can be very useful which is URL encoded. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.