# Lab 8: XSS with File Upload (file name)

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross-Site Scripting (XSS) can be exploited if there exists a file upload funtionality.

Over here we have a web application that asks to upload a file, it can be any file.  

## Steps to Reproduce

Let's upload a test file named `test.txt` and see what happens. 

![https://i.imgur.com/1q72XyI.png](https://i.imgur.com/1q72XyI.png)

Okay, so we can see that our file name is reflected on the page. Yes, REFLECTED! 

You know what i mean right? Yes, we are going to create a file named `<img src=x onerror=alert('XSS')>.png` and upload it to see if we can get a pop up. 

![https://i.imgur.com/DPS0dAh.png](https://i.imgur.com/DPS0dAh.png)

We got a XSS pop up :)

## Payload(s) Used

I have used the payload as a file name: `<img src=x onerror=alert('XSS')>.png` But for this lab, any XSS payload as a file name will work fine.

## Conclusion

This lab was an attempt to provide how one can perform XSS when we have a file upload functionality. The XSS we saw in this lab was Reflected XSS which has a severity of P3 with a CVSS score of 5.8 which is Medium.