# Week 4 Lab Solutions

[Open Redirect Lab Solutions](Week%204%20Lab%20Solutions%20ed406a5b11464e2aa462965fc427e624/Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449.md) 

[EXIF Data Exposure Lab Solution](Week%204%20Lab%20Solutions%20ed406a5b11464e2aa462965fc427e624/EXIF%20Data%20Exposure%20Lab%20Solution%20cf5008244f3e43129a09c51ce67ce24a.md)