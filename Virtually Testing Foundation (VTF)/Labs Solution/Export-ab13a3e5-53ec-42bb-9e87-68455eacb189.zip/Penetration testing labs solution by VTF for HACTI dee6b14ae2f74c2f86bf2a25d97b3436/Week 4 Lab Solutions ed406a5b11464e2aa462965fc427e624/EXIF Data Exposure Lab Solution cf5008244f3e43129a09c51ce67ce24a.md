# EXIF Data Exposure Lab Solution

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: Let's PII!](EXIF%20Data%20Exposure%20Lab%20Solution%20cf5008244f3e43129a09c51ce67ce24a/Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6.md)