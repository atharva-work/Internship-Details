# Lab 1: Let's PII!

---

## Introduction to the Lab

This lab will provide you a walkthrough of how EXIF Data not being stripped can lead to sensitive data exposure.

Over here we have "Profile Photo Upload" option!

## Steps to Reproduce

![Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled.png](Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled.png)

Ahaan! A file upload functionality! I can test a lot over here, but lets first try for some low hanging fruits like EXIF Sensitive Data Exposure! Let's quickly grab a picture from [`https://github.com/ianare/exif-samples`](https://github.com/ianare/exif-samples) and upload it!

![Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled%201.png](Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled%201.png)

Amazing! Now let's check out if the website stripped the sensitive data or not. To do this simply go to [`http://exif.regex.info/exif.cgi`](http://exif.regex.info/exif.cgi) and upload the image. Alternatively you can Copy the Image address and paste it.

![Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled%202.png](Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled%202.png)

Let's click on `View Image Data`.  Amazing!! Notice all the sensitive data being exposed which the website is not stripping it off!

![Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled%203.png](Lab%201%20Let's%20PII!%2020dfd9c4d907469ea1e552b68635fad6/Untitled%203.png)

Amazing! we found EXIF Data Exposure vulnerability

## Payload(s) Used

Images from [`https://github.com/ianare/exif-samples`](https://github.com/ianare/exif-samples) can work as payloads.

## Conclusion

This lab was an attempt to provide how EXIF Data Exposure can be exploited. The vulnerability we saw in this lab has a severity of P3.