# Open Redirect Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Use

### 4. Conclusion

[Lab 1: A simple Host!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%201%20A%20simple%20Host!%200e827e633f7c4d48ace739ec85e8445e.md)

[Lab 2: Story of a beautiful Header!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab.md)

[Lab 3: Sanitize Params!!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%203%20Sanitize%20Params!!%2082f540061fc44c1595a8b65e52f4e53d.md)

[Lab 4: Patterns are Important!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d.md)

[Lab 5: Patterns are Important Part 2!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%205%20Patterns%20are%20Important%20Part%202!%2001c76328e4e742beb886f82f991da47d.md)

[Lab 6: Same Param Twice!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%206%20Same%20Param%20Twice!%206a05382d5e0441a09b2097e797aee470.md)

[Lab 7: Domains ? Not Always!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2.md)

[Lab 8: Style Digit Symbols <3](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%208%20Style%20Digit%20Symbols%203%2099e899c9554e493cb9edab9890470343.md)

[Lab 9: File Upload!? Redirect IT!](Open%20Redirect%20Lab%20Solutions%206954dbe78cda49b1bf7afd9f33fd6449/Lab%209%20File%20Upload!%20Redirect%20IT!%202fb65b103eb5442692a119b724665daf.md)