# Lab 1: A simple Host!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how Open Redirect is done in real-life scenario.

In this Lab we will see how you can reproduce Open Redirect Vulnerability by changing the Host header.

## Steps to Reproduce

Hacker H !! Are you ready to redirect the victim to the attacker controlled website? Come on lets first check out what happens when you enter the URL [https://labs.hacktify.in/open_redirect/Lab 1/](https://labs.hacktify.in/open_redirect/Lab%201/)

![Lab%201%20A%20simple%20Host!%200e827e633f7c4d48ace739ec85e8445e/Untitled.png](Lab%201%20A%20simple%20Host!%200e827e633f7c4d48ace739ec85e8445e/Untitled.png)

We got redirected to `https://labs.hacktify.in`! Umm! Let me check out what is the request that is being sent and the corresponding response. Hacker H time to fire up your Burp!

![Lab%201%20A%20simple%20Host!%200e827e633f7c4d48ace739ec85e8445e/Untitled%201.png](Lab%201%20A%20simple%20Host!%200e827e633f7c4d48ace739ec85e8445e/Untitled%201.png)

All I can see over here is that a request is being sent to `[https://labs.hacktify.in](https://labs.hacktify.in)` via the `Host` header. Umm what if I convert the value of `Host` header to `evil.com`. Right! This can surely cause an Open Redirect. Let's test it out! The new request would look like

## Payload(s) Used

In this lab we just replaced the value of `Host` header with the malicious URL we wanted the victim to redirect to. Any malicious URL would work here.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by changing the value of `Host` header. The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.