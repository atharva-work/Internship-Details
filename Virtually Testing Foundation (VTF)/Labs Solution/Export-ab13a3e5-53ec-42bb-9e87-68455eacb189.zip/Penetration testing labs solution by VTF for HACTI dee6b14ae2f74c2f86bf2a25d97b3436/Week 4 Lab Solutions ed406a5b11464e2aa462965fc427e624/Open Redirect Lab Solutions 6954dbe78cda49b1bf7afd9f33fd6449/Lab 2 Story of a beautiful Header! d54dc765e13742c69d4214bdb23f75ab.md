# Lab 2: Story of a beautiful Header!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how Open Redirect is done in real-life scenario.

Over here we have a static web application which says "Welcome to OpenRedirect Page"

## Steps to Reproduce

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled.png)

Arghhh!! Just a static page, but from the last lab we know that changing the Host Header might redirect the page! Come on lets try it out! Fire up your Burp and lets get started! 

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%201.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%201.png)

Here is my request. A small tip always send the request to Repeater this allows you to replay the request as many times as you want. To do so simply click on `Action` and `Send to Repeater` or else you could use a shortcut key `Ctrl + R`

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%202.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%202.png)

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%203.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%203.png)

All right let's quickly change the `Host` header and check out!

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%204.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%204.png)

Oops! We got an 404 Not Found! That means this does not work! Now what? After a lot of research Hacker H came to know about a wonderful header called as `X-Forwarded-Host`

`X-Forwarded-Host`is a request-type header de-facto standard header. This header is used to identify the original request made by the client. Because the hostnames and the ports differ in the reverse proxies that time this header took the lead and identify the original request. This header can also be used for debugging, creating location-based content.

In simple terms a website without protections of `X-Forwarded-Host` can lead the victim redirect to a malicious website.

Sweet! Thats what we needed. Now its simple to exploit the vulnerability! I am simply going to add `X-Forwarded-Host` and then the user will be redirected to `https://evil.com`. The final request looks like this:

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%205.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%205.png)

Notice we get a `302 FOUND` and a new `Location` Header with value `[https://evil.com](https://evil.com)` on the response end. Lets check this out on the browser. To do this simply right click on the response side and click on `Show Response in Browser` and copy the request and paste it on a browser tab.

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%206.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%206.png)

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%207.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%207.png)

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Amazing! We were redirected to `https://evil.com`

## Payload(s) Used

In this lab we added a new header `X-Forwarded-Host: [evil.com](http://evil.com)` to redirect the victim to the attacker controlled website. You can use any website you want to redirect the user to with the header `X-Forwarded-Host`

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by adding the `X-Forwarded-Host` header. The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.