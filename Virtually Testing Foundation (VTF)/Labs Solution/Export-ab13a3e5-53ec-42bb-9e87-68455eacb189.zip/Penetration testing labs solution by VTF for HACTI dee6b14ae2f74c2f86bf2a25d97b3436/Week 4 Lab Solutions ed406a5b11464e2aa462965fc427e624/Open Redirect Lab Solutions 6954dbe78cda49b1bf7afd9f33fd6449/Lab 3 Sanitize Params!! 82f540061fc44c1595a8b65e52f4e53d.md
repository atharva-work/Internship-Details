# Lab 3: Sanitize Params!!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how Open Redirect is done in real-life scenario.

Over here we have a web application which tells us to login!

## Steps to Reproduce

![Lab%203%20Sanitize%20Params!!%2082f540061fc44c1595a8b65e52f4e53d/Untitled.png](Lab%203%20Sanitize%20Params!!%2082f540061fc44c1595a8b65e52f4e53d/Untitled.png)

Alright! Its time to visualize the application let's login and intercept the request to check out what happens! Fire up your Burp and let's get started.

![Lab%203%20Sanitize%20Params!!%2082f540061fc44c1595a8b65e52f4e53d/Untitled%201.png](Lab%203%20Sanitize%20Params!!%2082f540061fc44c1595a8b65e52f4e53d/Untitled%201.png)

So this is the request! Notice we have a parameter `url` which is being redirected to `dashboard.php`. What if we change that to `[evil.com](http://evil.com)` A slight possibility that the website can be redirected. All right! Let's test it. The final address looks like this:

![Lab%203%20Sanitize%20Params!!%2082f540061fc44c1595a8b65e52f4e53d/Untitled%202.png](Lab%203%20Sanitize%20Params!!%2082f540061fc44c1595a8b65e52f4e53d/Untitled%202.png)

Let's send this request and turn intercept off! 

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Amazing! We are now redirected to `[https://evil.com](https://evil.com)` and successfully exploited the Open Redirect vulnearbility.

## Payload(s) Used

In this lab we have changed the value of `url` parameter in order to redirect the victim to `https://evil.com` . You can use any website you want to redirect the user.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by changing the value of `url` parameter. The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.