# Lab 4: Patterns are Important!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of Open Redirect vulnerability using a strange pattern.

Over here we have a web application which tells us to login!

## Steps to Reproduce

![Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled.png](Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled.png)

Alright! Its time to visualize the application let's login and intercept the request to check out what happens! Fire up your Burp and let's get started.

![Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled%201.png](Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled%201.png)

Looks similar to the request in last Lab right? But it isn't. Lets quickly send this request to `Repeater`.  The magical tab which allows us to repeat the request numerous time.

All right! We already know that changing the URL won't work in this case but let's try it once.

![Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled%202.png](Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled%202.png)

So as expected, the victim was not redirected to `https://evil.com`. So here comes a pattern which looks like this [`example.com/#/path///google.com`](http://example.com/#/path///google.com) Let's analyze the pattern. [`example.com/#/path`](http://example.com/#/path///google.com) is the vulnerable endpoint of the vulnerable website. `///evil.com` basically redirects the vulnerable website to `evil.com`.

So let's try this in our lab. So the new request would look like

![Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled%203.png](Lab%204%20Patterns%20are%20Important!%20e3f38c713d5348f89f30045f3a76728d/Untitled%203.png)

Notice on sending the request we get a `302 FOUND` which will redirect you to `[https://evil.com](https://evil.com)`  Let's copy the response to the browser and check out.

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Perfect! we were able to redirect to `https://evil.com`. We successfully bypassed and exploited Open Redirection Vulnerability.

## Payload(s) Used

In this lab we have changed the value of `url` parameter in order to redirect the victim to `dashboard.php///evil.com` . You can use any website you want to redirect the user.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by using a pattern that is `[vulnerable.site///attacker.site](http://vulnerable.site///attacker.site)`  The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.