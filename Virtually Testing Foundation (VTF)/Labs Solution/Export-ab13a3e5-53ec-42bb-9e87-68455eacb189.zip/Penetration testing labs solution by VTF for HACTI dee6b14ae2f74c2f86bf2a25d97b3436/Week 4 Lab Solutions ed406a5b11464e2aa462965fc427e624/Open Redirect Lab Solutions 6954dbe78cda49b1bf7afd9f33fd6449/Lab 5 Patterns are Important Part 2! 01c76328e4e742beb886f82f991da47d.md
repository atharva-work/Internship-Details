# Lab 5: Patterns are Important Part 2!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of Open Redirect vulnerability using another strange pattern. Over here we have a web application which tells us to login!

## Steps to Reproduce

![Lab%205%20Patterns%20are%20Important%20Part%202!%2001c76328e4e742beb886f82f991da47d/Untitled.png](Lab%205%20Patterns%20are%20Important%20Part%202!%2001c76328e4e742beb886f82f991da47d/Untitled.png)

Alright! Its time to visualize the application let's login and intercept the request to check out what happens! Fire up your Burp, `Intercept` the request send it to `Repeater` and let's get started.

![Lab%205%20Patterns%20are%20Important%20Part%202!%2001c76328e4e742beb886f82f991da47d/Untitled%201.png](Lab%205%20Patterns%20are%20Important%20Part%202!%2001c76328e4e742beb886f82f991da47d/Untitled%201.png)

So over here we are going to see another pattern. We can use `@` symbol which redirects the website mentioned after the `@` symbol. So now our payload will become `dashboard.php@evil.com`

Let's try this out.

![Lab%205%20Patterns%20are%20Important%20Part%202!%2001c76328e4e742beb886f82f991da47d/Untitled%202.png](Lab%205%20Patterns%20are%20Important%20Part%202!%2001c76328e4e742beb886f82f991da47d/Untitled%202.png)

Notice on sending the request we get a `302 FOUND` which will redirect you to `[https://evil.com](https://evil.com)`  Let's copy the response to the browser and check out.

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Amazing! we found another technique to bypass and exploit the Open Redirect vulnerability.

## Payload(s) Used

In this lab we have changed the value of `url` parameter in order to redirect the victim to `dashboard.php@evil.com` . You can use any website you want to redirect the user.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by using a pattern that is `[vulnerable.site@attacker.site](http://vulnerable.site///attacker.site)`  The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.