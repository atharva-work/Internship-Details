# Lab 6: Same Param Twice!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how you can exploit Open Redirect vulnerability using same parameter twice. Over here we have a web application which tells us to login!

## Steps to Reproduce

![Lab%206%20Same%20Param%20Twice!%206a05382d5e0441a09b2097e797aee470/Untitled.png](Lab%206%20Same%20Param%20Twice!%206a05382d5e0441a09b2097e797aee470/Untitled.png)

Alright! Its time to visualize the application let's login and intercept the request to check out what happens! Fire up your Burp, `Intercept` the request send it to `Repeater` and let's get started.

![Lab%206%20Same%20Param%20Twice!%206a05382d5e0441a09b2097e797aee470/Untitled%201.png](Lab%206%20Same%20Param%20Twice!%206a05382d5e0441a09b2097e797aee470/Untitled%201.png)

So my Hacker friends did you'll wonder what would happen if the parameter `url` was given twice. Ahaan! I see three possibilities: 

1. Original one gets executed
2. New one gets executed
3. Both of them gets executed.

The 3rd scenario cannot happen since the developer wants to redirect its users to only one page. So either 1 or 2 can be the case! Let's find it out by adding the `url` parameter.

So now the new request would be:

![Lab%206%20Same%20Param%20Twice!%206a05382d5e0441a09b2097e797aee470/Untitled%202.png](Lab%206%20Same%20Param%20Twice!%206a05382d5e0441a09b2097e797aee470/Untitled%202.png)

Notice on sending the request we get a `302 FOUND` which will redirect you to `[https://evil.com](https://evil.com)`  Let's copy the response to the browser and check out. 

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Amazing! Open Redirect vulnerability was exploited.

So over here case 2 was exploited. Many servers handle multiple parameters in a different way. Some go for 1st parameter some for the last. So it is a good practice to check each one out.

## Payload(s) Used

In this lab we have added another `url` parameter in order to redirect the victim to `evil.com` . You can use any website you want to redirect the user.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by adding a `url` parameter with the value `evil.com`  The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.