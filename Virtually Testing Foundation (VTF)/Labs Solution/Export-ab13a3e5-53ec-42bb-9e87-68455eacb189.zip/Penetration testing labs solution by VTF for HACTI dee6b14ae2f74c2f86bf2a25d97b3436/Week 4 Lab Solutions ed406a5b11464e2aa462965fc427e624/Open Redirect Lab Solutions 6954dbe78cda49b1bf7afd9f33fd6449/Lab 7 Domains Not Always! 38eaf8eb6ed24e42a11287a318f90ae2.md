# Lab 7: Domains ? Not Always!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how you can exploit Open Redirect vulnerability without providing domain names. Over here we have a web application which tells us to login!

## Steps to Reproduce

![Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled.png](Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled.png)

Alright! Its time to visualize the application let's login and intercept the request to check out what happens! Fire up your Burp, `Intercept` the request send it to `Repeater` and let's get started.

![Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%201.png](Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%201.png)

Developers have become smarter now Hacker H! They block all cases we saw in the previous lab! So now what? Should we stop and declare that this was the lab which could not be exploited from Open Redirect?

Hell No! We hackers never loose! Let's try a workaround! Instead of using domain names what if we used IP addresses. A great chance that developers won't have whitelisted them

Amazing! Let's do it! But how do I find the IP address of `https://evil.com`. Pretty simple just run a `ping command` and you shall get the IP address.

![Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%202.png](Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%202.png)

Amazing now lets just put the IP address in the parameter `url` and check out. The final request would look like this:

![Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%203.png](Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%203.png)

Notice on sending the request we get a `302 FOUND` which will redirect you to `[https://evil.com](https://evil.com)`  Let's copy the response to the browser and check out. 

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Amazing! Open Redirect vulnerability was exploited using IP address

## Payload(s) Used

In this lab we have used IP address in the `url` parameter instead of the domain name in order to redirect the victim to `evil.com` . You can use IP address of any website you want to redirect the user.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by adding IP address to `url` parameter. The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.