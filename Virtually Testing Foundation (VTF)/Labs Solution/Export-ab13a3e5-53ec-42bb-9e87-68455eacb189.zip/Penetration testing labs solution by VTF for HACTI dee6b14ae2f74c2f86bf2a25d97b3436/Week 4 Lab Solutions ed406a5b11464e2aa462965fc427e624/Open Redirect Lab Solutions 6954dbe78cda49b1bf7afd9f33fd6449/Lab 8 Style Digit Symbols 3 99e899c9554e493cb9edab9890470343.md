# Lab 8: Style Digit Symbols <3

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how you can exploit Open Redirect vulnerability style digit domain names. Over here we have a web application which tells us to login!

## Steps to Reproduce

![Lab%208%20Style%20Digit%20Symbols%203%2099e899c9554e493cb9edab9890470343/Untitled.png](Lab%208%20Style%20Digit%20Symbols%203%2099e899c9554e493cb9edab9890470343/Untitled.png)

Alright! Its time to visualize the application let's login and intercept the request to check out what happens! Fire up your Burp, `Intercept` the request send it to `Repeater` and let's get started.

![Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%201.png](Lab%207%20Domains%20Not%20Always!%2038eaf8eb6ed24e42a11287a318f90ae2/Untitled%201.png)

Hacker H! Developer's learnt their mistake from the past and now have blocked both `Domain Names` as well as `IP Addresses` ! So now what? Do we loose? Nehh! Hacker H never looses! How about using `Style-digit symbols` A group of symbols which the developer most likely would not have blocked it.

```jsx
① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ ⑪ ⑫ ⑬ ⑭ ⑮ ⑯ ⑰ ⑱ ⑲ ⑳ ⑴ ⑵ ⑶ ⑷ ⑸ ⑹ ⑺ ⑻ ⑼ ⑽ ⑾
⑿ ⒀ ⒁ ⒂ ⒃ ⒄ ⒅ ⒆ ⒇ ⒈ ⒉ ⒊ ⒋ ⒌ ⒍ ⒎ ⒏ ⒐ ⒑ ⒒ ⒓ ⒔ ⒕ ⒖ ⒗
⒘ ⒙ ⒚ ⒛ ⒜ ⒝ ⒞ ⒟ ⒠ ⒡ ⒢ ⒣ ⒤ ⒥ ⒦ ⒧ ⒨ ⒩ ⒪ ⒫ ⒬ ⒭ ⒮ ⒯ ⒰
⒱ ⒲ ⒳ ⒴ ⒵ Ⓐ Ⓑ Ⓒ Ⓓ Ⓔ Ⓕ Ⓖ Ⓗ Ⓘ Ⓙ Ⓚ Ⓛ Ⓜ Ⓝ Ⓞ Ⓟ Ⓠ Ⓡ Ⓢ Ⓣ
Ⓤ Ⓥ Ⓦ Ⓧ Ⓨ Ⓩ ⓐ ⓑ ⓒ ⓓ ⓔ ⓕ ⓖ ⓗ ⓘ ⓙ ⓚ ⓛ ⓜ ⓝ ⓞ ⓟ ⓠ ⓡ ⓢ
ⓣ ⓤ ⓥ ⓦ ⓧ ⓨ ⓩ ⓪ ⓫ ⓬ ⓭ ⓮ ⓯ ⓰ ⓱ ⓲ ⓳ ⓴ ⓵ ⓶ ⓷ ⓸ ⓹ ⓺ ⓻ ⓼ ⓽ ⓾ ⓿
```

Ahaan Let's try that out! Let's create our payload first  [http://ⓔⓥⓘⓛⓔ.ⓒⓞⓜ](http://evil.com)

Amazing! Let's do it! But how do I find the IP address of `https://evil.com`. Pretty simple just run a `ping command` and you shall get the IP address.

The final request would look like this:

Image

Notice on sending the request we get a `302 FOUND` which will redirect you to `[https://evil.com](https://evil.com)`  Let's copy the response to the browser and check out. 

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Amazing! Open Redirect vulnerability was exploited using IP address

## Payload(s) Used

In this lab we have used style digit symbols in the `url` parameter instead of the domain name in order to redirect the victim to `evil.com` . You can use domain name of any website you want to redirect the user.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited by using style digit symbols. The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.