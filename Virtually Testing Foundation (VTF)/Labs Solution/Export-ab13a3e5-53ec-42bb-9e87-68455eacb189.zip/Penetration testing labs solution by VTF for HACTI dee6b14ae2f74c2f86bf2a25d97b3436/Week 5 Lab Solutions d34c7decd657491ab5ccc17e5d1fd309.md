# Week 5 Lab Solutions

[Cross Origin Resource Sharing Lab Solutions](Week%205%20Lab%20Solutions%20d34c7decd657491ab5ccc17e5d1fd309/Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d.md)