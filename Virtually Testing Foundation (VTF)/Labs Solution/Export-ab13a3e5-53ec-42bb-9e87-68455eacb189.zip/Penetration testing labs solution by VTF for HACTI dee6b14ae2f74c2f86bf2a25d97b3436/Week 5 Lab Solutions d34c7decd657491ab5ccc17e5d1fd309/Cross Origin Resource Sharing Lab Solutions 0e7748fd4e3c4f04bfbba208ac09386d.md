# Cross Origin Resource Sharing Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: CORS With Arbitrary Origin](Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d/Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c.md)

[Lab 2: CORS with Null origin](Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d/Lab%202%20CORS%20with%20Null%20origin%20ab28c75dd6b34928bc6fbcf558235c5f.md)

[Lab 3: CORS with prefix match](Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d/Lab%203%20CORS%20with%20prefix%20match%2036a7c7102b3e45c3981677fc29e4e3ec.md)

[Lab 4: CORS with suffix match](Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d/Lab%204%20CORS%20with%20suffix%20match%2017288b5f34a845fa9b9c8c3801535a2f.md)

[Lab 5: CORS with Escape dot](Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d/Lab%205%20CORS%20with%20Escape%20dot%20f936a36a98564f809b93e11961b2e7a8.md)

[Lab 6: CORS with Substring match](Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d/Lab%206%20CORS%20with%20Substring%20match%205031294d57c64d5292c42336393ac52e.md)

[Lab 7: CORS with Arbitrary Subdomain](Cross%20Origin%20Resource%20Sharing%20Lab%20Solutions%200e7748fd4e3c4f04bfbba208ac09386d/Lab%207%20CORS%20with%20Arbitrary%20Subdomain%207f70d3d7ab5c49f3aaea76ad04074b75.md)