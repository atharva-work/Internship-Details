# Lab 4: CORS with suffix match

## Introduction to the Lab

This lab is focused to show you how a CORS protection can be bypassed with certain match conditions and can lead to leak sensitive information in a web application. In this lab we will learn how an attacker can use suffix match condition in origin header to make a malicious request and fetch sensitive information from the web application.

## Steps to Reproduce:

We are given with a page which has a blank page. 

Let's capture this request in our burpsuite and send it to the repeater. 

![Lab%204%20CORS%20with%20suffix%20match%2017288b5f34a845fa9b9c8c3801535a2f/Untitled.png](Lab%204%20CORS%20with%20suffix%20match%2017288b5f34a845fa9b9c8c3801535a2f/Untitled.png)

Well, we already got `access-control-allow-credentials: true` . Now, in this case we can't directly use [attacker.com](http://attacker.com) or [hacktify.in.evil.com](http://hacktify.in.evil.com)  Origin header because the developer has implemented a check which mainly checks if [hacktify.in](http://hacktify.in) and something after hacktify.in are present in the Origin.

In this case, we can go for suffix match technique. What if we curate a Origin header something like this i.e) `evilhacktify.in`  where `evilhacktify.in` is owned by the attacker which only has the genuine domain name present in it. 

Let's try!

![Lab%204%20CORS%20with%20suffix%20match%2017288b5f34a845fa9b9c8c3801535a2f/Untitled%201.png](Lab%204%20CORS%20with%20suffix%20match%2017288b5f34a845fa9b9c8c3801535a2f/Untitled%201.png)

Got a response with `access-control-allow-origin: evilhacktify.in [](evilhacktify.in)`with `access-control-allow-credentials: true` which further confirms that this web application is vulnerable to CORS.

Time to Exploit :D

We have seen that if we send the captured request with no Origin then we get nothing, but if we add the origin header as mentioned above we got a body in the response.

![Lab%204%20CORS%20with%20suffix%20match%2017288b5f34a845fa9b9c8c3801535a2f/Untitled%202.png](Lab%204%20CORS%20with%20suffix%20match%2017288b5f34a845fa9b9c8c3801535a2f/Untitled%202.png)

## Payload(s) Used:

This lab cannot be exploited with the HTML POC that we have encountered before but as we have seen the same can be achieved in the burpsuite utility.

## Conclusion

This lab was based on a CORS when there ia a check on the user input. An attacker can use this bad implementation to fetch sensitive information from a web application by using the above technique. This is a common test case in most web app implementation. We will look into more such cases in the coming labs.