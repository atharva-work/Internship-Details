# Lab 6: CORS with Substring match

## Introduction to the Lab

This lab is focused to show you how a CORS protection can be bypassed with substring match conditions and can lead to leak sensitive information in a web application. In this lab we will learn how an attacker can use substring condition in origin header to make a malicious request and fetch sensitive information from the web application.

## Steps to Reproduce:

We are given with a page which has a blank page. 

Let's capture this request in our burpsuite and send it to the repeater. 

![Lab%206%20CORS%20with%20Substring%20match%205031294d57c64d5292c42336393ac52e/Untitled.png](Lab%206%20CORS%20with%20Substring%20match%205031294d57c64d5292c42336393ac52e/Untitled.png)

Well, we already got `access-control-allow-credentials: true` . In this case, we will see if the string match has been implemented properly, if not it may lead to CORS.

here, Suppose we are allowed to use [hacktify.in](http://hacktify.in) as origin but nothing other than that. We can't use suffix match or prefix match as well. Umm! The developer has made a smart move this time right?

Well, NO! We can still exploit this with substring match condition. 

How about using [hacktify.co](http://hacktify.co)  instead of [hacktify.com](http://hacktify.com) which can be owned by the potential attacker? Let's see if that works.

Let's try!

![Lab%206%20CORS%20with%20Substring%20match%205031294d57c64d5292c42336393ac52e/Untitled%201.png](Lab%206%20CORS%20with%20Substring%20match%205031294d57c64d5292c42336393ac52e/Untitled%201.png)

Got a response with `access-control-allow-origin: wwwhacktify.co` with `access-control-allow-credentials: true` which further confirms that this web application is vulnerable to CORS.

Time to Exploit :D

We have seen that if we send the captured request with no Origin then we get nothing, but if we add the origin header as mentioned above we got a body in the response.

![Lab%206%20CORS%20with%20Substring%20match%205031294d57c64d5292c42336393ac52e/Untitled%202.png](Lab%206%20CORS%20with%20Substring%20match%205031294d57c64d5292c42336393ac52e/Untitled%202.png)

## Payload(s) Used:

This lab cannot be exploited with the HTML POC that we have encountered before but as we have seen the same can be achieved in the burpsuite utility.

## Conclusion

This lab was based on a CORS when there ia a check on the user input. An attacker can use this bad implementation to fetch sensitive information from a web application by using the above technique. This is a common test case in most web app implementation. We will look into more such cases in the coming labs.