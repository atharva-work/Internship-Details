# Week 6 Lab Solutions

[Cross Site Request Forgery Lab Solutions](Week%206%20Lab%20Solutions%205563abdcbbc34d2e877cdd4d4cad082b/Cross%20Site%20Request%20Forgery%20Lab%20Solutions%20f8d0cc6f684c45169131ca63c207d362.md)