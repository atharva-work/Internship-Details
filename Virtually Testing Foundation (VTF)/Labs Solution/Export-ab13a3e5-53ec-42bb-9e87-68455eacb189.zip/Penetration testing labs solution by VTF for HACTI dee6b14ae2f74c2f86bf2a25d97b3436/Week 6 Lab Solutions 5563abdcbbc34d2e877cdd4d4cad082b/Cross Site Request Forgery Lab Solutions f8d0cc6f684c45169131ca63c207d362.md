# Cross Site Request Forgery Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: Eassyy CSRF](Cross%20Site%20Request%20Forgery%20Lab%20Solutions%20f8d0cc6f684c45169131ca63c207d362/Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd.md)

[Lab 2: Always Validate Tokens](Cross%20Site%20Request%20Forgery%20Lab%20Solutions%20f8d0cc6f684c45169131ca63c207d362/Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f.md)

[Lab 4: I hate when someone uses my tokens!](Cross%20Site%20Request%20Forgery%20Lab%20Solutions%20f8d0cc6f684c45169131ca63c207d362/Lab%204%20I%20hate%20when%20someone%20uses%20my%20tokens!%209d919f9588fc4e4eafe44f7e0c0850cd.md)

[Lab 6: GET me or POST me](Cross%20Site%20Request%20Forgery%20Lab%20Solutions%20f8d0cc6f684c45169131ca63c207d362/Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54.md)

[Lab 7 : XSS the saviour](Cross%20Site%20Request%20Forgery%20Lab%20Solutions%20f8d0cc6f684c45169131ca63c207d362/Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90.md)

[Lab 8: rm -rf token](Cross%20Site%20Request%20Forgery%20Lab%20Solutions%20f8d0cc6f684c45169131ca63c207d362/Lab%208%20rm%20-rf%20token%20effbc195b668467198dc297735147cd9.md)