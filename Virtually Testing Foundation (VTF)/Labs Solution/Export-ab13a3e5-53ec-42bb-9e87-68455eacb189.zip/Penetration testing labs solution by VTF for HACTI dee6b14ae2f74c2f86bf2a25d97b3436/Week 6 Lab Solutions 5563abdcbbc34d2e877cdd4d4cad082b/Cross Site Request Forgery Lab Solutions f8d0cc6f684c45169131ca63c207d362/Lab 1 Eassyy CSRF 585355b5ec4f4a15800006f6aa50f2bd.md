# Lab 1: Eassyy CSRF

## Introduction to the Lab

This lab's password change functionality is vulnerable to CSRF.

Over here we have a web application that asks us to sign in.

# Steps to Reproduce:

Let's begin...!!!

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled.png)

First, we will get a sign-in page. Let's create 2 accounts to check for CSRF vulnerability.

Let's first create the attacker's account.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%201.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%201.png)

This is the attacker's account with a password ——> `attacker@123`.

Now let's create the user's account.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%202.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%202.png)

This is the user's account password ——> `user@123`.

Now let's log in to the attacker's account.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%203.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%203.png)

We will get this page. Let's try to change the password and keep our Burp suite intercept mode on.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%204.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%204.png)

Here the password is changed from `atatcker@123` ———> `attack@123`.

Now submit the request and check the request in the Burp Suite.

Then click on the action tab and go to the engagement tools to generate CSRF PoC.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%205.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%205.png)

Copy this HTML code and save it to file.html.

Now login to the user's account.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%206.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%206.png)

Now open the file.html folder in the browser using the file location.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%207.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%207.png)

Then click on submit request.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%208.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%208.png)

It shows that the password has changed successfully.

Then go back and try to log in with your own password → `user@123` in the user account.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%209.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%209.png)

Let's log in.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%2010.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%2010.png)

Here we got an error. Let's log in with attack@123.

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%2011.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%2011.png)

![Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%2012.png](Lab%201%20Eassyy%20CSRF%20585355b5ec4f4a15800006f6aa50f2bd/Untitled%2012.png)

BOOM....!!! We are in ...!!! Therefore it's vulnerable to CSRF.

# Conclusion:

This lab was very simple here we just need to craft some HTML that uses a CSRF attack to change the viewer's password and upload it to your exploit server. We will look into more such cases in the coming labs.