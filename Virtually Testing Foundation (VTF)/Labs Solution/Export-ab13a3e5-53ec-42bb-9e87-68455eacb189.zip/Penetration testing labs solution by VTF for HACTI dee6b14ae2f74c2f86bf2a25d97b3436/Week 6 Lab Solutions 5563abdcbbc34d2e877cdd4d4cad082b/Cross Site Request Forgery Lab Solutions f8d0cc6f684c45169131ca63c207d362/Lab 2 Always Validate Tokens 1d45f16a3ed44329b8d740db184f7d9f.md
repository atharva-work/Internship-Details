# Lab 2: Always Validate Tokens

## Introduction to the Lab

In this lab, the CSRF token is not validated.

Over here we have a web application that tells us to sign in.

# Steps to Reproduce:

First Lets create 2 different accounts.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled.png)

This is the user's account with password `xyz@123`.

Let's create a second account.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%201.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%201.png)

This is the attacker account with password `attacker@123`.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%202.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%202.png)

Now let's log in to the attacker's account.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%203.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%203.png)

We are redirected to this page with change password functionality.

Let's go and change the password.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%204.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%204.png)

Here we are changing the password from `attacker123` —→ `attack@123`.When we click on submit button we intercepted the request through Burp-suite. Here we can see there is a CSRF token present in the request body. Now click on the `Action tab` and send it to the repeater.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%205.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%205.png)

Here in the `repeater tab`, we can see the csrf token lets try to change the token and see the response.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%206.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%206.png)

Here when we change the csrf token in the request body we see `200 OK` in the response which means the token is not validated.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%207.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%207.png)

Now go to the action tab and then to the engagement tools and click on generate `CSRF PoC`.Then copy the CSRF PoC and save it to the `file.html`.

Now let's log in with a different account.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%208.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%208.png)

Let's log in to the `xyz` account.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%209.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%209.png)

Now open the file.html in the browser using the file location.Then click on the submit request button.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2010.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2010.png)

Here we get that the password has been updated successfully.

Now let's log in to the xyz account again.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2011.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2011.png)

Here we are trying to log in to the xyz account using `xyz@123` as the password.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2012.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2012.png)

It gave us an error.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2013.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2013.png)

Now we are trying to log in xyz account using `attack@123` as the password.

![Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2014.png](Lab%202%20Always%20Validate%20Tokens%201d45f16a3ed44329b8d740db184f7d9f/Untitled%2014.png)

BOOM....!!!!! We are logged in successfully with the password `attack@123`.

Hence it's proof that the CSRF token is not validated and there is CSRF vulnerability.

# Conclusion:

This lab was very simple here we just need to check the CSRF token by changing its value and craft some HTML that uses a CSRF attack to change the viewer's password and upload it to your exploit server. We will look into more such cases in the coming labs.