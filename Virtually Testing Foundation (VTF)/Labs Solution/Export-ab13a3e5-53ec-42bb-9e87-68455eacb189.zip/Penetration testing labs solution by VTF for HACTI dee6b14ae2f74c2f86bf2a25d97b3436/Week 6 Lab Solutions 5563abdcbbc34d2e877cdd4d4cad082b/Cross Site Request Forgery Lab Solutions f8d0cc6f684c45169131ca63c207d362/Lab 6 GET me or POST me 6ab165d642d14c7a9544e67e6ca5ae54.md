# Lab 6: GET me or POST me

## Introduction to the Lab

This lab's request method is vulnerable to CSRF.

# Steps to reproduce:

Let's begin...!!!

First, create 2 accounts as shown before in earlier labs.

I have already created 2 accounts one `user@gmail.com` with password `user@123` and second `attacker@gmail.com` with password `attacker@123.`

![Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled.png](Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled.png)

Now login to the attacker account with the password `attacker@123`.

![Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%201.png](Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%201.png)

We are redirected to this page. Let's change the password.

![Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%202.png](Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%202.png)

Here we are changing the password from `attacker@123` → `attack@123` and while we clicked on the submit button we intercepted the request in Burpsuite. Here we can see there is a CSRF token. Now click on the Action tab and send the request to the repeater.

![Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%203.png](Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%203.png)

Now when we try to change the CSRF token we can see in the response body it's giving an invalid CSRF token and the password didn't change.

Let's try to change the request method.

Go to the Action tab and click on the change request method.

![Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%204.png](Lab%206%20GET%20me%20or%20POST%20me%206ab165d642d14c7a9544e67e6ca5ae54/Untitled%204.png)

sHere we can see that the password has changed successfully.

# 

# Conclusion:

This lab was very simple here we just need to change the request method to change the password successfully,