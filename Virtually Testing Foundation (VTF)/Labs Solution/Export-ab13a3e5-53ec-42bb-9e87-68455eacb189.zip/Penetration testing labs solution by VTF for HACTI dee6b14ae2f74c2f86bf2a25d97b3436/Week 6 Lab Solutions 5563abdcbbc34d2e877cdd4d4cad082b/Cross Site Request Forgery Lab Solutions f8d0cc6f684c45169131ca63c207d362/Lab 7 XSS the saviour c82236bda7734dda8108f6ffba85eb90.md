# Lab 7 : XSS the saviour

## Introduction to the Lab

This lab is vulnerable to XSS attacks. Through XSS we can get the cookie and the CSRF token

# Steps to Reproduce:

Let's begin...!!!

I have already created an account where the email is `user@gmail.com` and the password is `user@123`.

![Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled.png](Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled.png)

Let's log in to the user account.

![Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%201.png](Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%201.png)

We are redirected to this page.

![Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%202.png](Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%202.png)

Now lets try to enter a simple payload here `<script>alert(1)</script>` .

![Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%203.png](Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%203.png)

BOOM...!! XSS got reflected.

Let's try another payload.

![Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%204.png](Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%204.png)

Lets try `<script>alert(document.cookie)</script>` payload.

![Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%205.png](Lab%207%20XSS%20the%20saviour%20c82236bda7734dda8108f6ffba85eb90/Untitled%205.png)

Nice...!! It got reflected with CSRF token as `csrf_token=9f30abfb7a0141bb657fa6d587a5878b;`.

# Payload used:

**<script>alert(1)</script>**

**<script>alert(document.cookie)</script>**

# 

# Conclusion:

This lab was very simple here we just need to use XSS payload to get the CSRF token.