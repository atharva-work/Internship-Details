# Week 7 Lab Solutions

[Server-Side Request Forgery Lab Solutions](Week%207%20Lab%20Solutions%20e6d8607fb4e0438dbf0cd86297e97c71/Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77.md)