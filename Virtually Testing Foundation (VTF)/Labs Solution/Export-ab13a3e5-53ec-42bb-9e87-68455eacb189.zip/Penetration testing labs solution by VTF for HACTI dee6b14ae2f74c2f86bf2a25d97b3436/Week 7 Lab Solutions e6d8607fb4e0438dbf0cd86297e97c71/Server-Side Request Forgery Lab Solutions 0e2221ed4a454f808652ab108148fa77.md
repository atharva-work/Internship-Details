# Server-Side Request Forgery Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: Get The 127.0.0.1](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3.md)

[Lab 2: http(s)? Nevermind!!](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%202%20http(s)%20Nevermind!!%208677613139734693b1b97821d3c4b722.md)

[Lab 3: ":" The saviour!](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8.md)

[Lab 4: Messed up Domain!](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%204%20Messed%20up%20Domain!%20b1ffd58e7651455fa88829ef78752bbe.md)

[Lab 5: Decimal IP](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%205%20Decimal%20IP%2066dc3b09cc4d4f55b61f6b407e383c1d.md)

[Lab 6: short-hand IP address](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%206%20short-hand%20IP%20address%208727ab0642c742ff9ff240a479e67829.md)

[Lab 7: File Upload to SSRF!](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8.md)

[Lab 8: SSRF with DNS Rebinding](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e.md)

[Lab 9: Look an SSRF on Cloud!](Server-Side%20Request%20Forgery%20Lab%20Solutions%200e2221ed4a454f808652ab108148fa77/Lab%209%20Look%20an%20SSRF%20on%20Cloud!%20ead5f1bea91a4e0e9d30504b9b9abb98.md)