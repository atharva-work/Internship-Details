# Lab 3: ":" The saviour!

## Introduction to the Lab:

This lab has been designed to show you how we can get access to the system's [localhost](http://localhost) due to a very improper server side request check. This lab will show you how we can simply get the internal localhost access on any vulnerable web application.

But, there is a twist here! We can't directly access 127.0.0.1 nor we can use protocol like http or https as we did previously. But we can find a way to bypass this implementation.

## Steps to Reproduce:

In the given lab, we can see that we have been asked for an url.

![Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png](Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png)

Let us try to access `[http://localhost:80](http://localhost:80)`

![Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png](Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png)

Opps, It gives us a message "You've been blocked!!". Well, the developer did a good job here. But you know what we can still bypass this check. If you check this repository [https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Server Side Request Forgery#bypass-localhost-with-](https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Server%20Side%20Request%20Forgery#bypass-localhost-with-) then you will learn that we can use two colon to bypass the word localhost or 127.0.0.1. Let's try this out and let's access localhost using `http://[::]:80/` 

![Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled%201.png](Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled%201.png)

Wow!! That was cool! We can use double colon "::" to bypass the above check to get valid SSRF. 

## Payload(s) Used:

In this lab, we have seen that if the server checks for specific word or ip and restricts us then we can use two colon to bypass the check and get internal access to [localhost](http://localhost) using `http://[::]:80/`

## Conclusion

This lab explained you how you can bypass a checks that has been implemented to prevent SSRF which was further proved not to be a proper fix for the problem. Eventually we will learn more about some bypass in upcoming labs.