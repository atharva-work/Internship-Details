# Lab 4: Messed up Domain!

## Introduction to the Lab:

This lab has been designed to show you how we can get access to the system's [localhost](http://localhost) due to a very improper server side request check. This lab will show you how we can simply get the internal localhost access on any vulnerable web application.

This time, the developer has gained maximum knowledge to prevent SSRF. Let's see what they have got so far

## Steps to Reproduce:

In the given lab, we can see that we have been asked for an url.

![Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png](Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png)

Let us try to access `[http://localhost:80](http://localhost:80)`

![Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png](Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png)

Again blocked! You can try other ways discussed so far. But in this lab we will teach you a new and interesting way to bypass these checks. We will use domain redirection technique to prove SSRF in this lab. We know that we can't use [http://localhost:80](http://localhost:80) or 127.0.0.1 to bypass this check. But what if we try to access a domain like [http://customer1.app.localhost.my.company.127.0.0.1.nip.io/](http://customer1.app.localhost.my.company.127.0.0.1.nip.io/) which will redirect us to localhost.

Let's try!

Awesome! It worked

![Lab%204%20Messed%20up%20Domain!%20b1ffd58e7651455fa88829ef78752bbe/Untitled.png](Lab%204%20Messed%20up%20Domain!%20b1ffd58e7651455fa88829ef78752bbe/Untitled.png)

 So, with this we can say that we can use Domain redirection using [http://customer1.app.localhost.my.company.127.0.0.1.nip.io/](http://customer1.app.localhost.my.company.127.0.0.1.nip.io/)  to bypass SSRF checks.

## Payload(s) Used:

In this lab, we have seen that if the server checks for specific word or ip and restricts us then we can use domain redirection to get internal access to [localhost](http://localhost) using [`http://customer1.app.localhost.my.company.127.0.0.1.nip.io/`](http://customer1.app.localhost.my.company.127.0.0.1.nip.io/)

## Conclusion

This lab explained you how you can bypass a checks that has been implemented to prevent SSRF which was further proved not to be a proper fix for the problem. Eventually we will learn more about some bypass in upcoming labs.