# Lab 5: Decimal IP

## Introduction to the Lab:

This lab has been designed to show you how we can get access to the system's admin panel due to a very improper server side request check. This lab will show you how we can simply get the internal Admin panel access on any vulnerable web application.

This time, the developer has gained maximum knowledge to prevent SSRF and implemented a fix for our previous bypasses. 

## Steps to Reproduce:

In the given lab, we can see that we have been asked for an url.

![Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png](Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png)

Let us try to access `[http://localhost:80](http://localhost:80)`

![Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png](Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png)

Again blocked! Well here we need to think like a hacker. Sometimes, browser acts in a way where if we provide a decimal conversion of any IP which is further decoded by the browser and allows us to access some internal services like [localhost](http://localhost) or 127.0.0.1. Let's see how this work. If you know what is decimal numbers then we can try to change any IP or 127.0.0.1 to decimal values and use those values to access internal services. 

Some testcases has been provided below:

```bash
http://2130706433 = http://127.0.0.1
http://3232235521 = http://192.168.0.1
http://3232235777 = http://192.168.1.1
http://2852039166  = http://169.254.169.254
```

Now, let's try to access the Admin Panel running on [localhost](http://localhost) which is 127.0.0.1 using `http://213070643`

![Lab%205%20Decimal%20IP%2066dc3b09cc4d4f55b61f6b407e383c1d/Untitled.png](Lab%205%20Decimal%20IP%2066dc3b09cc4d4f55b61f6b407e383c1d/Untitled.png)

This is how we can use decimal numbers to gain SSRF in a vulnerable web application.

## Payload(s) Used:

In this lab, we have seen that if the server checks for specific word or ip and restricts us then we can use decimal values of the IP to get internal access to Admin panel using `http://213070643`

## Conclusion

This lab explained you how you can bypass a checks that has been implemented to prevent SSRF which was further proved not to be a proper fix for the problem. Eventually we will learn more about some bypass in upcoming labs.