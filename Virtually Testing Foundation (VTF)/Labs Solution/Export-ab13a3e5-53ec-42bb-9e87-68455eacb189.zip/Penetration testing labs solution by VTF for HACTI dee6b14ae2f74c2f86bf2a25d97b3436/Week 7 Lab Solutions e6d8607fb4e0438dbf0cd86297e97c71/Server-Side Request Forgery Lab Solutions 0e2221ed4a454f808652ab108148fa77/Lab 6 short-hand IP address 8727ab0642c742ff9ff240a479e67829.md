# Lab 6: short-hand IP address

## Introduction to the Lab:

This lab has been designed to show you how we can get access to the system's admin panel due to a very improper server side request check. This lab will show you how we can simply get the internal Admin panel access on any vulnerable web application.

This time, the developer has gained more knowledge to prevent SSRF and implemented a fix for our previous bypasses. 

## Steps to Reproduce:

In the given lab, we can see that we have been asked for an url.

![Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png](Lab%201%20Get%20The%20127%200%200%201%205938541fa3c44213a6e231ddf34a76d3/Untitled.png)

Let us try to access `[http://localhost:80](http://localhost:80)`

![Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png](Lab%203%20The%20saviour!%201a2c4094a07a4f6baa808d5e92f162e8/Untitled.png)

Cool!

Seems to be a good fix, but not the perfect one. We can try to bypass this check with Short-hand IP addressing. We can use this technique to gain SSRF in a vulnerable web application. 

Some test cases has been mentioned bellow: 

```markdown
http://0/
http://127.1
http://127.0.1
```

Let's try these above test cases and see if we can gain access to Admin Panel.

![Lab%206%20short-hand%20IP%20address%208727ab0642c742ff9ff240a479e67829/Untitled.png](Lab%206%20short-hand%20IP%20address%208727ab0642c742ff9ff240a479e67829/Untitled.png)

Awesome! We have got the admin panel using `http://127.1` 

## Payload(s) Used:

In this lab, we have seen that if the server checks for specific word or ip and restricts us then we can use short hand IP address to get internal access to Admin panel using `http://127.1`

## Conclusion

This lab explained you how you can bypass a checks that has been implemented to prevent SSRF which was further proved not to be a proper fix for the problem. Eventually we will learn more about some bypass in upcoming labs.