# Lab 7: File Upload to SSRF!

## Introduction to the Lab:

This lab has been designed to show you how we can get access to the system's admin panel by using the file upload functionality. This lab will show you how we can simply get the internal Admin panel access on any vulnerable web application.

So over here we have a file upload functionality. 

## Steps to Reproduce:

![Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled.png](Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled.png)

Awesome! What if we create a file which on uploading sends a request to our server!

Ahaan! Sounds evil File Upload to SSRF amazing! Alright Let's fire up our Burp Suite and Create a Collaborator Client. 

Simultaneously let's quickly create an `svg` file which will send a request to our Burp Collaborator Client. The file would look like:

```markdown
<svg xmlns:svg="http://www.w3.org/2000/svg"
xmlns="http://www.w3.org.2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink" width="200" height="200">
<image height="30" width="30"
xlink:href="https://<Any-Server>" />
<polygon id="triangle" points="0,0 0,50 50,0" fill="#009900" stroke="#004400"/>
</svg>
```

Perfect let's upload the file and intercept the request!

![Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled%201.png](Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled%201.png)

Notice our payload is being uploaded as we wanted!

![Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled%202.png](Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled%202.png)

Perfect! The file has been uploaded! Let's take a look at the collaborator client and check out if we have got any request or not.

![Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled%203.png](Lab%207%20File%20Upload%20to%20SSRF!%20d54743dbbabe4031b85ec2eb084a52b8/Untitled%203.png)

Amazing! We received a HTTP request that proves our SSRF vulnerability

## Payload(s) Used:

For this lab we have used the below code:

```jsx
<svg xmlns:svg="http://www.w3.org/2000/svg"
xmlns="http://www.w3.org.2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink" width="200" height="200">
<image height="30" width="30"
xlink:href="https://<Any-Server>" />
<polygon id="triangle" points="0,0 0,50 50,0" fill="#009900" stroke="#004400"/>
</svg>
```

## Conclusion

This lab explained you how you can exploit SSRF vulnerability using File Upload feature on a web application.