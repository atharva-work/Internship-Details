# Lab 8: SSRF with DNS Rebinding

## Introduction to the Lab:

This lab has been designed to show you how we can get access to the system's admin panel using DNS Rebinding. This lab will show you how we can simply get the internal Admin panel access on any vulnerable web application.

So over here we have an Online WebPage Loader.

## Steps to Reproduce:

![Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled.png](Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled.png)

Let us try to access `[http://localhost:80](http://localhost:80)`

![Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled%201.png](Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled%201.png)

Oops! Seems like the developer has given a solid fix to our SSRF Payloads. Uh-Oh! Now What? Umm! How about using a technique called as DNS Rebinding! 

DNS Rebinding? Never heard before? No worries we got you covered! 

DNS rebinding is a method of manipulating resolution of domain names. It resolves to an IP and next time to a local IP. One such example is [b0x.mannulinux.org](http://b0x.mannulinux.org/). This is useful to bypass configurations which resolves the given domain and check it against a white-list and then try to access it again (as it has to resolve the domain again a different IP can be served by the DNS).

More info on DNS Rebinding can be found here : [`https://geleta.eu/2019/my-first-ssrf-using-dns-rebinfing/`](https://geleta.eu/2019/my-first-ssrf-using-dns-rebinfing/)

Alright! So it's time to enter the payload which is  [b0x.mannulinux.org](http://b0x.mannulinux.org/) and check out!

![Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled%202.png](Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled%202.png)

Uh-Huh! This is a blacklisted IP!!?? Umm How about testing it once again??

![Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled%203.png](Lab%208%20SSRF%20with%20DNS%20Rebinding%20b459c847c5b5468988e2e6003302401e/Untitled%203.png)

Perfect! Notice we got the Admin Panel Access!

Note: You may receive `This is a blacklisted IP` twice or thrice keep trying and you shall get the access to Admin Panel

## Payload(s) Used:

In this lab, we have used the payload [`b0x.mannulinux.org`](http://b0x.mannulinux.org/) which rebinds to `127.0.0.1` to get internal access to Admin panel.

## Conclusion

This lab explained you how you can bypass checks that has been implemented to prevent SSRF which was further proved not to be a proper fix for the problem using the technique of DNS rebinding.