# Lab 9: Look an SSRF on Cloud!

## Introduction to the Lab:

This lab has been designed to show you how we can get sensitive information of a Cloud VM Instance if the web application is vulnerable to SSRF attacks!

So over here we have an Online WebPage Loader!

## Steps to Reproduce:

![Lab%209%20Look%20an%20SSRF%20on%20Cloud!%20ead5f1bea91a4e0e9d30504b9b9abb98/Untitled.png](Lab%209%20Look%20an%20SSRF%20on%20Cloud!%20ead5f1bea91a4e0e9d30504b9b9abb98/Untitled.png)

Alright! Lets try our simple basic payload and try to access the Admin Panel which is `[http://localhost:80](http://localhost:80)`

![Lab%209%20Look%20an%20SSRF%20on%20Cloud!%20ead5f1bea91a4e0e9d30504b9b9abb98/Untitled%201.png](Lab%209%20Look%20an%20SSRF%20on%20Cloud!%20ead5f1bea91a4e0e9d30504b9b9abb98/Untitled%201.png)

Ahaan! An easy win of a perfect SSRF! But wait our website is hosted on a Cloud VM and Hacker H remember `Cloud = Sensitive data` ! What if this SSRF can lead to some sensitive data disclosure!

Sweet! There are certain end points which can lead you to such sensitive data.

For

Amazon AWS - [`http://169.254.169.254/latest/meta-data/iam/security-credentials/`](http://169.254.169.254/latest/meta-data/iam/security-credentials/)

Google Cloud Platform - [`http://metadata.google.internal/computeMetadata/v1/`](http://metadata.google.internal/computeMetadata/v1/)

Alright! Hacker H Time to increase the severity! Let's use the endpoint [`http://169.254.169.254/latest/meta-data/iam/security-credentials/`](http://169.254.169.254/latest/meta-data/iam/security-credentials/) and check out if we are able to get some sensitive information or not!

![Lab%209%20Look%20an%20SSRF%20on%20Cloud!%20ead5f1bea91a4e0e9d30504b9b9abb98/Untitled%202.png](Lab%209%20Look%20an%20SSRF%20on%20Cloud!%20ead5f1bea91a4e0e9d30504b9b9abb98/Untitled%202.png)

Sweet! Notice we have managed to get the server metadata.

## Payload(s) Used:

In this lab, we have used the payload `[http://localhost:80](http://localhost:80)` in order to prove the SSRF attack and the endpoint [`http://169.254.169.254/latest/meta-data/iam/security-credentials/`](http://169.254.169.254/latest/meta-data/iam/security-credentials/) in order to get the Amazon AWS Metadata. The endpoint [`http://metadata.google.internal/computeMetadata/v1/`](http://metadata.google.internal/computeMetadata/v1/) can be used to get the metadata for GCP.

## Conclusion

This lab explained you how you can increase the severity of SSRF by disclosing sensitive files if SSRF vulnerable web application is hosted on some Cloud VM Instance.