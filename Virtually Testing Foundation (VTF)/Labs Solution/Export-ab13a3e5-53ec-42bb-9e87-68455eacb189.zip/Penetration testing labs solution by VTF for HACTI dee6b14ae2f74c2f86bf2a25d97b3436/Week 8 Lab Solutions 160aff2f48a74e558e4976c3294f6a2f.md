# Week 8 Lab Solutions

[Insecure Direct Object Reference Lab Solutions](Week%208%20Lab%20Solutions%20160aff2f48a74e558e4976c3294f6a2f/Insecure%20Direct%20Object%20Reference%20Lab%20Solutions%20206ffdb1937e41b3b1de661fe489f483.md)