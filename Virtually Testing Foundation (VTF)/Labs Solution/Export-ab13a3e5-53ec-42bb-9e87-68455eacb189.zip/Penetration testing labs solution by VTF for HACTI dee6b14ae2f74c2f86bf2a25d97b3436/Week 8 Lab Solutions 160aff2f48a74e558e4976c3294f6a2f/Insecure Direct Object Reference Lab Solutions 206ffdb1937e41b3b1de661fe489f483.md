# Insecure Direct Object Reference Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: Give me my amount!!](Insecure%20Direct%20Object%20Reference%20Lab%20Solutions%20206ffdb1937e41b3b1de661fe489f483/Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd.md)

[Lab 2: Stop polluting my params!](Insecure%20Direct%20Object%20Reference%20Lab%20Solutions%20206ffdb1937e41b3b1de661fe489f483/Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799.md)

[Lab 3: Someone changed my Password 🙀!](Insecure%20Direct%20Object%20Reference%20Lab%20Solutions%20206ffdb1937e41b3b1de661fe489f483/Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb.md)

[Lab 4: Change your methods!](Insecure%20Direct%20Object%20Reference%20Lab%20Solutions%20206ffdb1937e41b3b1de661fe489f483/Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2.md)