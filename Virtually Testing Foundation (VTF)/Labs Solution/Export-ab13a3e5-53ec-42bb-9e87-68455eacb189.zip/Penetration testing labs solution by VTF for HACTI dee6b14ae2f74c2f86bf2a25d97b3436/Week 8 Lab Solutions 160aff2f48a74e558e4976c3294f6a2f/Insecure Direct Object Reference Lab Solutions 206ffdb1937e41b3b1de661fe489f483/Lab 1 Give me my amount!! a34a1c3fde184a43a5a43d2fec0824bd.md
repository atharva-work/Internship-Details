# Lab 1: Give me my amount!!

## Introduction to the Lab

This Lab will provide you a walkthrough of how IDOR is done in real-life scenario.

Over here we have a web application which is a bank application

## Steps to Reproduce

![Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled.png](Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled.png)

Alright Let's quickly Log In to the application!

![Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%201.png](Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%201.png)

Ahaan! A user profile section where in I can update my records! Thats nice! But wait what there is an `id` parameter present in the `URL`.

Time for some evil-ness!! What if I change the parameter to some other `id`? Will the application stop me or will I be able to see someone else's details. Let's check this out.

First let's update `id=1`  and check out.

![Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%202.png](Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%202.png)

![Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%203.png](Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%203.png)

Notice the User Details changed! Let's edit his `Credit Card` and `Update` the profile.

![Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%204.png](Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%204.png)

Let's have a look at the database.

The below image shows `before` clicking `Update`

![Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%205.png](Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%205.png)

The below image shows `after` clicking `Update`

![Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%206.png](Lab%201%20Give%20me%20my%20amount!!%20a34a1c3fde184a43a5a43d2fec0824bd/Untitled%206.png)

Perfect! We just found an IDOR!! 

## Payload(s) Used

In this lab we just changed the `id` parameter to some other value.

## Conclusion

This lab was an attempt to provide how IDOR can be exploited. The IDOR we saw in this lab has a severity of P3.