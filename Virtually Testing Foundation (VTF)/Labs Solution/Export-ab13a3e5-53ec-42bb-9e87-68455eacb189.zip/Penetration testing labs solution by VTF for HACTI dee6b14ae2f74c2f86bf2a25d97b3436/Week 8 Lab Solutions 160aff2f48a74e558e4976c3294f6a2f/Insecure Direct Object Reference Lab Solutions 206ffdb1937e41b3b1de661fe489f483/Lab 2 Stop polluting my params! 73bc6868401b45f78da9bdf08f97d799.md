# Lab 2: Stop polluting my params!

## Introduction to the Lab

This Lab will provide you a walkthrough of how IDOR is done in real-life scenario by polluting the parameters.

Over here we have a web application wherein we have a User Profile.

## Steps to Reproduce

![Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled.png](Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled.png)

Alright Let's try to  update our profile!

![Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%201.png](Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%201.png)

Let's quickly capture this request in Burp and check out what exactly is happening! So fire up your Burpsuite and `Intercept` the request.

![Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%202.png](Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%202.png)

Notice there is an `id` parameter being passed. We could have changed this parameter but what if it does not update other users details. Well how about adding the same parameter twice and confusing the web application. Seems Amazing! All right set your tools Hacker H and add the second parameter of the same name i.e. `id`

![Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%203.png](Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%203.png)

Let's send this request and check out our database.

The below image shows `before` sending the request.

![Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%204.png](Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%204.png)

The below image shows `after` sending the request

![Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%205.png](Lab%202%20Stop%20polluting%20my%20params!%2073bc6868401b45f78da9bdf08f97d799/Untitled%205.png)

Woahh!! We just polluted the parameter and performed a successful IDOR!!

## Payload(s) Used

In this lab we just added the `id` parameter with the value of the victim's account.

## Conclusion

This lab was an attempt to provide how IDOR can be exploited. The IDOR we saw in this lab has a severity of P3.