# Lab 3: Someone changed my Password 🙀!

## Introduction to the Lab

This Lab will provide you a walkthrough of how IDOR can lead to account takeover of a user

Over here we have a web application wherein we have a Login Page.

## Steps to Reproduce

![Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled.png](Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled.png)

Let's quickly Log In into the application.

![Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%201.png](Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%201.png)

MHmmm! A change Password field! 

![Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%202.png](Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%202.png)

How about abusing this. So let us say what if we change our password change the `id` field so that the other user's password gets changed and we can log in to perform an account takeover. Sweet! Sounds like a plan! Lets get ready.

Let's quickly change our password. Fire on Burp and `Intercept` the request.

![Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%203.png](Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%203.png)

Notice the parameter `username` Let's quickly update it to some other user. How about `admin` ;)

![Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%204.png](Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%204.png)

All right! Let's send the request and Boom! `admin` user's password got changed!

Let's check out our database.

The below image shows `before` sending the request.

![Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%205.png](Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%205.png)

The below image shows `after` sending the request

![Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%206.png](Lab%203%20Someone%20changed%20my%20Password%20%F0%9F%99%80!%20233f3077e29242bf9ce77dc8cda25ffb/Untitled%206.png)

Amazing! IDOR to account takeover! 

## Payload(s) Used

In this lab we just replaced the `username` parameter with the value of the victim's account.

## Conclusion

This lab was an attempt to provide how IDOR can be exploited to a permanent account takeover. The IDOR we saw in this lab has a severity of P2.