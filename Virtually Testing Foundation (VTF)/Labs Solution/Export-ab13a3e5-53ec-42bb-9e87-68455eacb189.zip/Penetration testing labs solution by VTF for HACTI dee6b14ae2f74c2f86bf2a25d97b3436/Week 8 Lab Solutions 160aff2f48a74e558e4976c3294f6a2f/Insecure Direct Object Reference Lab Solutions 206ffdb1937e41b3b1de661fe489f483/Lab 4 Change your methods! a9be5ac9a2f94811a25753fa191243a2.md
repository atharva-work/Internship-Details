# Lab 4: Change your methods!

## Introduction to the Lab

This Lab will provide you a walkthrough of how IDOR can be exploited when GET method is blocked

Over here we have a web application wherein we have a Login Page.

## Steps to Reproduce

![Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled.png](Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled.png)

Let's quickly Log In into the application.

![Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%201.png](Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%201.png)

Ahaan! A Update profile request! But this time the developer has become smarter! He has blocked our `GET` request. But no worries we are hackers smarter than these developers.

So let's quickly update our profile, `intercept` the request and send it to `repeater`

![Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%202.png](Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%202.png)

Notice the `id` parameter. Let's quickly change it to the one of the victim. And since developer has blocker our `GET` request, let's use a workaround. How about changing the `GET` request to `POST` Ahaan! Why not try it?

So the final request will be.

![Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%203.png](Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%203.png)

Let's quickly send this request and Perfect! 

![Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%204.png](Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%204.png)

Notice in the response we receive the details of the victim.

Let's check our database now!

The below image shows `before` sending the request.

![Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%205.png](Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%205.png)

The below image shows `after` sending the request

![Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%206.png](Lab%204%20Change%20your%20methods!%20a9be5ac9a2f94811a25753fa191243a2/Untitled%206.png)

Amazing! We have found another method to exploit IDOR! 

## Payload(s) Used

In this lab we just replaced the `id` parameter with the value of the victim's account. Additionally we replace the `GET` method to `POST` You can also use `PUT` method.

## Conclusion

This lab was an attempt to provide how IDOR can be exploited if `GET` method is blocked. The IDOR we saw in this lab has a severity of P2.