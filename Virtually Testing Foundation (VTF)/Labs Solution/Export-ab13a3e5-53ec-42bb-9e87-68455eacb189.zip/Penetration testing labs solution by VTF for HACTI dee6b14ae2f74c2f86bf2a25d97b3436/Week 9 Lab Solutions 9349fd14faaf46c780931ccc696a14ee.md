# Week 9 Lab Solutions

[SQL Injection Lab Solutions](Week%209%20Lab%20Solutions%209349fd14faaf46c780931ccc696a14ee/SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face.md)