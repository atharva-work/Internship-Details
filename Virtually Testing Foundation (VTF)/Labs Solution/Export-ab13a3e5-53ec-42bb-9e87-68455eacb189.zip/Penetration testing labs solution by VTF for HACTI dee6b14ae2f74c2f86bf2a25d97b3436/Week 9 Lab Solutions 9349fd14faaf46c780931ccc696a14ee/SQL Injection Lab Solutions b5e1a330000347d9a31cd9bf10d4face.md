# SQL Injection Lab Solutions

# # Basic lab 1

### 1. Introduction to the lab

### 2. Steps to Reproduce

### 3. Payload Used

### 4. Conclusion

[Lab 1: Strings & Errors Part 1!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%201%20Strings%20&%20Errors%20Part%201!%20bbeff4cca7314f01b4a7e0c6c924b16e.md)

[Lab 2: Strings & Errors Part 2!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33.md)

[Lab 3: Strings & Errors Part 3!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%203%20Strings%20&%20Errors%20Part%203!%20522efde6108242a68d909a9a3652b1bc.md)

[Lab 4: Let's Trick 'em!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%204%20Let's%20Trick%20'em!%20ab7dd7fad64747109cf8a803d578f0e0.md)

[Lab 5: Booleans and Blind!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%205%20Booleans%20and%20Blind!%200da6fbbb541a4403a4bb2865013acd67.md)

[Lab 6: Error Based : Tricked](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6.md)

[Lab 7: Errors and Post!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%207%20Errors%20and%20Post!%2092d6b4a0d9b74dba8487793350cb942b.md)

[Lab 8: User Agents lead us!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9.md)

[Lab 9: Referer lead us!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9.md)

[Lab 10: Oh Cookies!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec.md)

[Lab 11: WAF's are injected!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f.md)

[Lab 12: WAF's are injected Part 2!](SQL%20Injection%20Lab%20Solutions%20b5e1a330000347d9a31cd9bf10d4face/Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0.md)