# Lab 1: Strings & Errors Part 1!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which tell us to log in into the Admin Panel.

## Steps to Reproduce

![Lab%201%20Strings%20&%20Errors%20Part%201!%20bbeff4cca7314f01b4a7e0c6c924b16e/Untitled.png](Lab%201%20Strings%20&%20Errors%20Part%201!%20bbeff4cca7314f01b4a7e0c6c924b16e/Untitled.png)

All right lets try to add a payload in the password field. Lets use the payload `1"OR"1"="1`

![Lab%201%20Strings%20&%20Errors%20Part%201!%20bbeff4cca7314f01b4a7e0c6c924b16e/Untitled%201.png](Lab%201%20Strings%20&%20Errors%20Part%201!%20bbeff4cca7314f01b4a7e0c6c924b16e/Untitled%201.png)

![Lab%201%20Strings%20&%20Errors%20Part%201!%20bbeff4cca7314f01b4a7e0c6c924b16e/Untitled%202.png](Lab%201%20Strings%20&%20Errors%20Part%201!%20bbeff4cca7314f01b4a7e0c6c924b16e/Untitled%202.png)

Perfect! We performed a successful SQL Injection.

## Payload(s) Used

The payload used is `1"OR"1"="1`  Let's understand the payload. First we break the functionality by `1"` This makes the query at the backend incomplete. We than make the use of a logical operator `OR` which will result `true` whenever any one of the condition is `true`.  The `"1"="1` is a true condition in order to make the entire query true.

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.