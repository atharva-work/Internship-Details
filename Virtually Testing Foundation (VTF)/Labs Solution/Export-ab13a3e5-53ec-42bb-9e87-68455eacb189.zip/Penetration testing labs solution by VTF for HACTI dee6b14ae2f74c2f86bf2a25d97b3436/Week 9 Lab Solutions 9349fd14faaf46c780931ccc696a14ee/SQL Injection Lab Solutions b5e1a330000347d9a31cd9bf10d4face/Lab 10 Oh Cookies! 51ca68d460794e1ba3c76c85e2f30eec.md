# Lab 10: Oh Cookies!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which has a Admin portal and tells us to login.

## Steps to Reproduce

![Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled.png](Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled.png)

Alright! Let's try to login into the system with the default username `admin`  and password `admin`

![Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%201.png](Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%201.png)

Woahh!! A lot of information! `Cookie` seems to be an interesting endpoint which we can exploit. Let's go to our `Developer Tools` and edit this cookie information and add `'` to the value of it.

![Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%202.png](Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%202.png)

![Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%203.png](Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%203.png)

Perfect! Notice we got the error! Let's check this!

First to confirm that the developer is using `'` s we can use the payload `admin' or '1'='1 #`

![Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%204.png](Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%204.png)

Awesome! We can use a payload `' union select 1, database(),version() #` This will return us the database name and the version name.

![Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%205.png](Lab%2010%20Oh%20Cookies!%2051ca68d460794e1ba3c76c85e2f30eec/Untitled%205.png)

Awesome! We now learnt a method to exploit SQL Injection using Cookies!

## Payload(s) Used

The payload used is `admin' or '1'='1 #`  Let's understand the payload. First we break the functionality by `'` This makes the query at the backend incomplete. We know that developer has made use of `'`s So we make the use of a logical operator `OR`  which will result `true` whenever any one of the condition is `true`.  The `'1'='1` is a true condition in order to make the entire query true with the balancing using `''`s which makes the entire query complete. We didn't add `'` at the end since already `'` will be present in the query written at the backend. The `#` at the end comments the rest of the query.

Similarly, `' union select 1, database(),version() #` was used which will give the output of 1st row, `database()` will give the database name and `version()` will give the version name of MySQL.

## 

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.