# Lab 11: WAF's are injected!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which tell us to make use of the `id` parameter.

## Steps to Reproduce

![Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled.png](Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled.png)

Alright! Let's try to add the id parameter with the value `1` to it.

![Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%201.png](Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%201.png)

Perfect! Let's try to add `'` in the input!

![Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%202.png](Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%202.png)

Uh-Oh! Our input was blocked by WAF! Let's try to input a non digit and check!

![Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%203.png](Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%203.png)

Oops! No Luck! How about adding the id parameter one more time just like we did it in IDOR. Let's try it out! 

![Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%204.png](Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%204.png)

Perfect! Let's try to add `'` on our 2nd `id` param

![Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%205.png](Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%205.png)

Awesome! We got the error! Perfect now we can use the payload `'union select 1,user(),6--+`

![Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%206.png](Lab%2011%20WAF's%20are%20injected!%205b4a0da61aa54ec599e63ac017e08a7f/Untitled%206.png)

Perfect! We bypassed the WAF to successfully exploit SQL Injection!

## Payload(s) Used

The payload used is `2'union select 1,user(),6--+`  Let's understand the payload. First we break the functionality by `'` This makes the query at the backend incomplete. Then we use `union` keyword which combines the result. We `select` data from `column 1` and then from `user()` table and then from `column 6`. The `--+` comments out the remaining query.

## 

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.