# Lab 12: WAF's are injected Part 2!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which tell us to make use of the `id` parameter.

## Steps to Reproduce

![Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled.png](Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled.png)

Alright! Let's try to add the id parameter with the value `1` to it.

![Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%201.png](Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%201.png)

From the previous lab we now know that the WAF will not accept non digit and `'` but we can bypass it by concatenating another `id` Let's try it.

![Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%202.png](Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%202.png)

Perfect! Let's try to add `'` to our 2nd `id` param!

![Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%203.png](Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%203.png)

Oops! No Luck! Let's try adding `"`

![Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%204.png](Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%204.png)

Perfect! Notice `)` in the error message. The developer has made the query at the backend using `)`

This can be bypassed easily by using the payload `2") union select 1,user(),8--+`

![Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%205.png](Lab%2012%20WAF's%20are%20injected%20Part%202!%204183b65878a542c5946d596e9775efb0/Untitled%205.png)

Perfect! We bypassed the WAF to successfully exploit SQL Injection!

## Payload(s) Used

The payload used is `2") union select 1,user(),8--+`  Let's understand the payload. First we break the functionality by `")` This makes the query at the backend incomplete. Then we use `union` keyword which combines the result. We `select` data from `column 1` and then from `user()` table and then from `column 8`. The `--+` comments out the remaining query.

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.