# Lab 2: Strings & Errors Part 2!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which tell us to make use of the `id` parameter.

## Steps to Reproduce

![Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled.png](Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled.png)

Alright Let's try to add the parameter `id` and a value to it! 

![Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%201.png](Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%201.png)

Perfect! So this means that on changing the value of parameter `id` we can find email and password associated to that account. Alright let's try by entering the value `2`

![Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%202.png](Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%202.png)

Perfect lets add a `1'` and check out.

![Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%203.png](Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%203.png)

Amazing! So now we know that the application makes use of MySQL and hence there can possibly be an SQL Injection. Let us breakdown and understand the error first.

The query running at the backend to display a list of users must be something:

`$query = "SELECT * FROM clients WHERE id= '$id'";`

Our ultimate goal over here is to return everything present in the database. A simple payload `1' or 1=1 --`  can be used to perform the malicious action

Awesome! Let's try it out and check out what happens!

![Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%204.png](Lab%202%20Strings%20&%20Errors%20Part%202!%205f6ed45f9357428aa5065284847b5d33/Untitled%204.png)

Perfect! We performed a successful SQL Injection. Remember to URL encode the payload always!

## Payload(s) Used

The payload used is `1' or 1=1 --`   Let's understand the payload. First we break the functionality by `1'` This makes the query at the backend incomplete. We than make the use of a logical operator `OR` which will result `true` whenever any one of the condition is `true`.  The `1=1` is a true condition in order to make the entire query true. The `--`  will comment out the rest part of the code.

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.