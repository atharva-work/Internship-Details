# Lab 3: Strings & Errors Part 3!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which tell us to make use of the `id` parameter.

## Steps to Reproduce

![Lab%203%20Strings%20&%20Errors%20Part%203!%20522efde6108242a68d909a9a3652b1bc/Untitled.png](Lab%203%20Strings%20&%20Errors%20Part%203!%20522efde6108242a68d909a9a3652b1bc/Untitled.png)

Alright Let's try to add the parameter `id` and a value to it with a `\` in order to break the query! 

![Lab%203%20Strings%20&%20Errors%20Part%203!%20522efde6108242a68d909a9a3652b1bc/Untitled%201.png](Lab%203%20Strings%20&%20Errors%20Part%203!%20522efde6108242a68d909a9a3652b1bc/Untitled%201.png)

Amazing! As expected we have got the error! Let's break this error down!

`'"1\"'` Over here the `'`s around it denote our input. The `"`s denotes that the developer has made use of `"` to wrap the query. 

The query running at the backend to display a list of users must be something:

`$query = "SELECT * FROM clients WHERE id= $id";`

Our ultimate goal over here is to return everything present in the database. A simple payload `1" or 1=1 --`  can be used to perform the malicious action

Awesome! Let's try it out and check out what happens!

![Lab%203%20Strings%20&%20Errors%20Part%203!%20522efde6108242a68d909a9a3652b1bc/Untitled%202.png](Lab%203%20Strings%20&%20Errors%20Part%203!%20522efde6108242a68d909a9a3652b1bc/Untitled%202.png)

Perfect! We performed a successful SQL Injection. Remember to URL encode the payload always!

## Payload(s) Used

The payload used is `1" or 1=1 --`   Let's understand the payload. First we break the functionality by `1"` We used `"` here since the developer has wrapped the query in `"`s. This makes the query at the backend incomplete. We than make the use of a logical operator `OR` which will result `true` whenever any one of the condition is `true`.  The `1=1` is a true condition in order to make the entire query true. The `--`  will comment out the rest part of the code.

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.