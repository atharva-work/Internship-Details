# Lab 5: Booleans and Blind!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which tell us to make use of the `id` parameter.

## Steps to Reproduce

![Lab%205%20Booleans%20and%20Blind!%200da6fbbb541a4403a4bb2865013acd67/Untitled.png](Lab%205%20Booleans%20and%20Blind!%200da6fbbb541a4403a4bb2865013acd67/Untitled.png)

Alright Let's try to add the parameter `id` and add `\` to break it

All right. Let's try to add some special characters in order to break the query. 

![Lab%205%20Booleans%20and%20Blind!%200da6fbbb541a4403a4bb2865013acd67/Untitled%201.png](Lab%205%20Booleans%20and%20Blind!%200da6fbbb541a4403a4bb2865013acd67/Untitled%201.png)

Okay! So now we have got no error's. Well so is SQL Injection not possible? Umm! How about trying for a Blind SQL Injection. Usually developers do not print the error message but that does not mean SQL Injection is not possible.

Over here we know that the database name is `sqli` so we can test for Blind SQL Injection using the payload `1' AND (ascii(substr((select database()) ,3,3)) = 108 –+`

Awesome! Let's try it out and check out what happens!

![Lab%205%20Booleans%20and%20Blind!%200da6fbbb541a4403a4bb2865013acd67/Untitled%202.png](Lab%205%20Booleans%20and%20Blind!%200da6fbbb541a4403a4bb2865013acd67/Untitled%202.png)

Perfect! We performed a successful Blind SQL Injection. Remember to URL encode the payload always!

## Payload(s) Used

The payload used is `1' AND (ascii(substr((select database()) ,3,3)) = 108 –+`  Let's understand the payload. First we break the functionality by `1'` . This makes the query at the backend incomplete. We than make the use of a logical operator `AND` which will result `true` whenever both the conditions are `true`.  The `ascii` is a function in MySQL which returns the ascii number of the word matched. `substr` returns the substring which is matched between the given lengths. The `select` is an keyword which select's something. `database()` returns the database name.

So in this entire payload we return the ascii number of the database's third alphabet and match with 108 which in turn gets true. We comment the rest of the query and this makes us dump the row leading us to see the details.

The query could be modified by changing the ascii number `108` . We can in fact write a query to match any alphabet.

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.