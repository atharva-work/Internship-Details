# Lab 6: Error Based : Tricked

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which has a Admin portal and tells us to login.

## Steps to Reproduce

![Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled.png](Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled.png)

Alright Let's try to add `'` in the `Password` field to check out what exactly happens.

![Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled%201.png](Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled%201.png)

Oh! So the developer has not used`'` Let's try to enter `"` and check out if we are able to break the query!

![Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled%202.png](Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled%202.png)

Amazing! Let's break this error down!

`'""") LIMIT 0,1'` Over here the outside `'`s are the part of query. The inside set of `"`s represent our input. And the second `"` denotes our input. The `) LIMIT 0,1` is the part of the query. 

The query running at the backend to display a list of users must be something:

`$query = "SELECT * FROM table WHERE email=($email) AND password=($password) LIMIT 0,1";`

Our ultimate goal over here is to login into the Admin Panel. 

A  payload `") or ("1")=("1` if entered in the `Password` field should make us login. Let's try it out!

Awesome! Let's try it out and check out what happens!

![Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled%203.png](Lab%206%20Error%20Based%20Tricked%20420f075885ea450d9ea42d04dfa3a0a6/Untitled%203.png)

Perfect! We were able to bypass and Login to the Admin Panel!!

## Payload(s) Used

The payload used is `") or ("1")=("1`  Let's understand the payload. First we break the functionality by `")` This makes the query at the backend incomplete. We than make the use of a logical operator `OR`  which will result `true` whenever any one of the condition is `true`.  The `("1")=("1` is a true condition in order to make the entire query true with the balancing using `()`'s which makes the entire query complete. We didn't add `)` at the end since already `)` will be present in the query written at the backend.

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.