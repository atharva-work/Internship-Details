# Lab 8: User Agents lead us!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which has a Admin portal and tells us to login.

## Steps to Reproduce

![Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled.png](Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled.png)

Alright! Notice this lab tells us our IP address. Umm! From our previous experience let's try to login into the system!

![Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%201.png](Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%201.png)

So we have logged into the system

Awesome! Let's try it out and check out what happens! And we can see our `User Agent`! This can be used as an entry point for our SQL Injection!  Alright let's fire up our Burp! Send the request to `Repeater` add `'` in User Agent and check out!

![Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%202.png](Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%202.png)

All right seeing the error `'127.0.0.1', 'admin@gmail.com')'` we can guess the query. The query would be `$query="INSERT INTO table (user_agent, ip_address, email) VALUES ('".$user_agent."', '".$ip."', '".$email."')";`

Now when we know the query we can use the payload `' OR '1'='1` and this will be stored in the database.

![Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%203.png](Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%203.png)

Let's have a look at the database

![Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%204.png](Lab%208%20User%20Agents%20lead%20us!%20579c5b1c2ee7475abc342c57be1ff5e9/Untitled%204.png)

Perfect! We saw a new way to exploit SQL Injection

## Payload(s) Used

The payload used is `' or '1'='1`  Let's understand the payload. First we break the functionality by `'` This makes the query at the backend incomplete. We know that developer has made use of `'`s So we make the use of a logical operator `OR`  which will result `true` whenever any one of the condition is `true`.  The `'1'='1` is a true condition in order to make the entire query true with the balancing using `''`s which makes the entire query complete. We didn't add `'` at the end since already `'` will be present in the query written at the backend.

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.