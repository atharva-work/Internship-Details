# Lab 9: Referer lead us!

## Introduction to the Lab

This Lab will provide you a walkthrough of how SQL Injection is done in real-life scenario.

Over here we have a web application which has a Admin portal and tells us to login.

## Steps to Reproduce

![Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled.png](Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled.png)

Alright! Notice this lab tells us our IP address. Umm! From our previous experience let's try to login into the system!

![Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%201.png](Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%201.png)

So we have logged into the system

Awesome! Let's try it out and check out what happens! And we can see our `User Agent`! This can be used as an entry point for our SQL Injection!  Alright let's fire up our Burp! Send the request to `Repeater` add `'` in User Agent and check out!

![Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%202.png](Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%202.png)

Oops! This time the developer has protected `User-Agent` from SQL Injection! So what now??

Well let's try to inject our payload in `Referer Header` and check out! 

![Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%203.png](Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%203.png)

Ahaan! A step closer! Notice our input is being reflected! But still error is not being seen. Now let's try to break the query using `"` instead of `'`

![Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%204.png](Lab%209%20Referer%20lead%20us!%2026a7e68604af49abbfaabbf4c8e2b5c9/Untitled%204.png)

Perfect! We broke the query! All right seeing the error `'"""), '127.0.0.1')'` we now know this is similar to the previous lab.

Now we can use the payload `" or "1"="1`

## Payload(s) Used

The payload used is `" or "1"="1`  Let's understand the payload. First we break the functionality by `"` This makes the query at the backend incomplete. We know that developer has made use of `"`s So we make the use of a logical operator `OR`  which will result `true` whenever any one of the condition is `true`.  The `"1"="1` is a true condition in order to make the entire query true with the balancing using `""`s which makes the entire query complete. We didn't add `"` at the end since already `"` will be present in the query written at the backend.

## Video Link PoC

## Conclusion

This lab was an attempt to provide how SQL Injection can be exploited. The SQL Injection we saw in this lab has a severity of P2.